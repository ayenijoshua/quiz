<!--   USER PANEL PAGE              -->


<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="products">	 
	<div class="container">
             <ul id="myTab" class="nav customtab nav-tabs">
<li class="nav-item active">
<a href="#profile"  data-toggle="tab">
Profile
</a>
</li>

<li class="nav-item">
<a href="#orders"  data-toggle="tab">
Orders
</a>
</li>

<li class="nav-item">
<a href="#change-pass"  data-toggle="tab">
Change Password
</a>
</li>

<li class="nav-item">
<a href="#secure"  data-toggle="tab">
Secure your Account
</a>
</li>

</ul>
            <div id="myTabContent" class="tab-content">
                
                <div class="tab-pane fade in active profile" id="profile" aria-expanded="true">
                    
                    <div id="upd-callback">
                    <?=$profile_upd_form?>
                        </div>
                </div> 
                
                <div class="tab-pane fade in" id="orders" aria-expanded="true">
                    <?=$orders?>  
                </div>
                
                <div class="tab-pane fade in" id="change-pass" aria-expanded="true">
                    <?=$change_password_form?>    
                </div>
                
                <div class="tab-pane fade in" id="secure" aria-expanded="true">
                      
                </div>
                 
            </div>	
	</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>