<?php
if(isset($_SESSION['user_id'])){
 $product_controller->userTimer('home','user_id');   
}
  
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.smartaddons.com/templates/html/market/home8.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Nov 2017 16:28:55 GMT -->
<head>
    
    <!-- Basic page needs
	============================================ -->
	<title>Market - Premium Multipurpose HTML5/CSS3 Theme</title>
	<meta charset="utf-8">
    <meta name="keywords" content="boostrap, responsive, html5, css3, jquery, theme, multicolor, parallax, retina, business" />
    <meta name="author" content="Magentech">
    <meta name="robots" content="index, follow" />
   
	<!-- Mobile specific metas
	============================================ -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	
	<!-- Favicon
	============================================ -->
    <link rel="shortcut icon" href="ico/favicon.png">
	
	<!-- Google web fonts
	============================================ -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
    <!-- Libs CSS
	============================================ -->
    <link rel="stylesheet" href="assets/css/bootstrap/css/bootstrap.min.css">
	<link href="assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<link href="assets/js/datetimepicker/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <link href="assets/js/owl-carousel/owl.carousel.css" rel="stylesheet">
	<link href="assets/css/themecss/lib.css" rel="stylesheet">
	<link href="assets/js/jquery-ui/jquery-ui.min.css" rel="stylesheet">
	
	<!-- Theme CSS
	============================================ -->
   	<link href="assets/css/themecss/so_megamenu.css" rel="stylesheet">
        <link href="assets/css/themecss/so-categories.css" rel="stylesheet">
	<link href="assets/css/themecss/so-listing-tabs.css" rel="stylesheet">
	<link href="assets/css/themecss/so-newletter-popup.css" rel="stylesheet">
	<link href="assets/css/header8.css" rel="stylesheet">
	<link href="assets/css/footer5.css" rel="stylesheet">
	<link id="color_scheme" href="assets/css/home8.css" rel="stylesheet">
	<link href="assets/css/responsive.css" rel="stylesheet">
        <link href="assets/css/notify.css" rel="stylesheet">
        <script type="text/javascript" src="assets/js/jquery-2.2.4.min.js"></script>
        
        <script>
 
$(document).ready(function() { 
        
        cartProcessor('.add-to-cart-form','','manage-cart','.cart-callback');
        formProcessorWithCallbacks('.view-cart-form','view-cart-btn','#generic-modal-body',
        ' <span class="pull-right badge cart-callback" style="background-color:red;"><?=isset($_SESSION['cart'])?$_SESSION['cart']->totalQty :'' ?></span> <i class="fa fa-cart-arrow-down" aria-hidden="true"></i>',
        'manage-cart','.cart-callback');
        
        
        
}); 

</script>
	
        <style>
    .view-cart-btn{
    border: none;
    -webkit-border-radius: 50%;
    -moz-border-radius: 50%;
    -o-border-radius: 50%;
    -ms-border-radius: 50%;
    border-radius: 50%;
    font-size: 50px;
    outline: none;
    } 
    .modal-window{   
    width: 300px;
    top: 50%;
    left:50%;
    position:fixed;
    z-index:99999;
    }
    .pattern{
       background-image: url("<?=$site_bg_img?>");
    }
    .header-center-bg{
        background-color:<?=$header_center_bg_colour?>;   
    }
    .header-bottom{
        background-color:<?=$header_bottom_bg_colour?>;   
    }
    .header-top{
        background-color:<?=$footer_bg_colour?>;   
    }
    
        </style>
        
           
</head>

<body class="common-home res layout-home8 pattern">

	
    <div id="wrapper" class="<?=$site_layout?> banners-effect-1">
	<!-- Preloading Screen -->
	<div class="ip-header">
		<h1 class="ip-logo">
			<a href="home">
				<img src="assets/image/demo/logos/theme_logo.png" alt="SW Shoppy">
			</a>
		</h1>
		<div class="ip-loader">
			<svg class="ip-inner" width="60px" height="60px" viewBox="0 0 80 80">
				<path class="ip-loader-circlebg" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"></path>
				<path id="ip-loader-circle" class="ip-loader-circle" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z" style="stroke-dashoffset: 0; stroke-dasharray: 192.617;"></path>
			</svg>
		</div>
	</div>
	<!-- End Preloading Screen -->
	
	<!-- Header Container  -->
	<header id="header" class="variantleft type_8">
	<div class="header-top compact-hidden">
	<div class="container">
		<div class="row">
			<div class="header-top-left form-inline col-sm-6 col-xs-12 compact-hidden">
			</div>
			<div class="header-top-right collapsed-block text-right  col-sm-6 col-xs-12 compact-hidden">
				<h5 class="tabBlockTitle visible-xs">More<a class="expander " href="#TabBlock-1"><i class="fa fa-angle-down"></i></a></h5>
				<div class="tabBlock" id="TabBlock-1">
					<ul class="top-link list-inline">
                                            <li class="wishlist">
                                                 <form action="manage-cart" id="" method="post" class="last view-cart-form">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="action" value="view-cart" />
                                                <button data-toggle="modal" data-target="#genericModal" class="btn btn-sm btn-rounded btn-warning fa fa-heart-o" type="submit" id=""> Wish List</button>
                                                     </form>
                                            </li>
						<li class="">
                                                     <form action="manage-cart" id="" method="post" class="last view-cart-form">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="action" value="view-cart" />
                                                <button data-toggle="modal" data-target="#genericModal" class="btn btn-sm btn-rounded btn-warning fa fa-cart-plus" type="submit" id=""> Shopping Cart</button>
                                                     </form>
                                                </li>
                                                <li class="login">
                                                    <form class="review-form" method="post" action="manage-user">
                                                   <?php echo e(csrf_field()); ?>

                                                  <input type="hidden" name="action" value="review">
                                                  <button data-toggle="modal" data-target="#genericModal" id="review-btn" onclick="formProcessorWithCallbacks('.review-form','.review-btn','.generic-modal-body','Review','manage-user','','','')" 
                                                      type="submit" class="btn-sm btn btn-rounded btn-warning fa fa-check-square review-btn"> Checkout</button>
                                                  </form>
                                                </li>
						<?=$get_signedin_user?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
		<!-- Header Top -->
		
		<!-- //Header Top -->

		<!-- Header center -->
                <div class="header-center" style="background-color:<?=$header_center_bg_colour?>">
			<div class="container ">
				<div class="row">
					<!-- Logo -->
					<div class="navbar-logo col-md-3 col-sm-12 col-xs-12">
						<a href="home"><img src="assets/image/demo/logos/logo_8.png" title="Your Store" alt="Your Store"></a>
					</div>
					<!-- //end Logo -->
					
					<!-- Search -->
					<div id="sosearchpro" class="col-md-5 col-sm-7 search-pro">
						<form method="GET" action="">
							<div id="search0" class="search input-group">
								<div class="select_category filter_type icon-select">
									<select class="no-border" name="category_id">
										<option value="0">All Categories</option>
										<option value="78">Apparel</option>
										<option value="77">Cables &amp; Connectors</option>
										<option value="82">Cameras &amp; Photo</option>
										<option value="80">Flashlights &amp; Lamps</option>
										<option value="81">Mobile Accessories</option>
										<option value="79">Video Games</option>
										<option value="20">Jewelry &amp; Watches</option>
										<option value="76">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Earings</option>
										<option value="26">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wedding Rings</option>
										<option value="27">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Men Watches</option>
									</select>
								</div>

								<input class="autosearch-input form-control" type="text" value="" size="50" autocomplete="off" placeholder="Enter keywords to search..." name="search">
								<span class="input-group-btn">
								<button type="submit" class="button-search btn btn-primary" name="submit_search"><i class="fa fa-search"></i></button>
								</span>
							</div>
							<input type="hidden" name="route" value="product/search">
						</form>
					</div>
					<!-- //Search -->
					
					<!-- Main Menu -->
					<div class="phone-contact col-md-2  hidden-md hidden-sm hidden-xs">
							<div class="inner-info">
								<strong>Call us Now:</strong><br>
								<span>Toll free:  (+234) 81-026-26183</span>
							</div>
					</div>
					<!-- //Main Menu -->

					<!-- Shopping Cart -->
					    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12 shopping_cart pull-right">
						<!--cart-->
                                                <form action="manage-cart" id=""  method="post" class="last view-cart-form">
                                                <?php echo e(csrf_field()); ?>	
                                                <input type="hidden" name="action" value="view-cart" />
                                                <button data-toggle="modal" data-target="#genericModal" class="view-cart-btn btn-rounded btn-warning fa fa-cart-plus" type="submit" id="">
                                                    <span class="badge pull-left qty-callback">
                                                        <?=isset($_SESSION['cart'])?$_SESSION['cart']->totalQty :'' ?>
                                                    </span> <span class="badge pull-right price-callback">₦
                                                        <?=isset($_SESSION['cart'])?$_SESSION['cart']->totalPrice :'' ?>
                                                    </span>
                                                </button>
                                                </form>
						<!--//cart-->
					    </div>
					<!-- //Shopping Cart -->
				</div>

			</div>
		</div>
		<!-- //Header center -->

		<!-- Header Bottom -->
                <div class="header-bottom" style="background-color:<?=$header_bottom_bg_colour?>">
	<div class="container">
		<div class="row">
			
			<div class="sidebar-menu col-md-3 col-sm-6 col-xs-12 ">
				<div class="responsive so-megamenu ">
					<div class="so-vertical-menu no-gutter compact-hidden">
						<nav class="navbar-default">	
							
							<div class="container-megamenu vertical">
								<div id="menuHeading">
									<div class="megamenuToogle-wrapper">
										<div class="megamenuToogle-pattern">
											<div class="container">
												<div>
													<span></span>
													<span></span>
													<span></span>
												</div>
												All Categories							
												<i class="fa pull-right arrow-circle fa-chevron-circle-up"></i>
											</div>
										</div>
									</div>
								</div>
								<div class="navbar-header">
									<button type="button" id="show-verticalmenu" data-toggle="" class="navbar-toggle fa fa-list-alt">
										
									</button>
									All Categories		
								</div>
								<div class="vertical-wrapper" >
									<span id="remove-verticalmenu" class="fa fa-times"></span>
									<div class="megamenu-pattern">
										<div class="container">
											<ul class="megamenu">
												<?=$category_list?>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</nav>
					</div>
				</div>

			</div>
			
			<!-- Main menu -->
			<div class="megamenu-hori header-bottom-right  col-md-9 col-sm-6 col-xs-12 ">
				<div class="responsive so-megamenu ">
	<nav class="navbar-default">
		<div class=" container-megamenu  horizontal">
			<div class="navbar-header">
				<button type="button" id="show-megamenu" data-toggle="collapse" class="navbar-toggle">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				Navigation		
			</div>
			
			<div class="megamenu-wrapper">
				<span id="remove-megamenu" class="fa fa-times"></span>
				<div class="megamenu-pattern">
					<div class="container">
						<ul class="megamenu " data-transition="slide" data-animationtime="250">
							<li class="home hover">
								<a href="home">Home</a>
							</li>
							<li>
								<a href="about" class="clearfix">
									<strong>About</strong>
								</a>
							</li>
                                                        <li>
								<a href="contact" class="clearfix">
									<strong>Contact</strong>
								</a>
							</li>
						<?=$get_signedin_user?>
						</ul>
						
					</div>
				</div>
			</div>
		</div>
	</nav>
</div>
	</div>
			<!-- //end Main menu -->
			
		</div>
	</div>

</div>

	<!-- Navbar switcher -->
	<!-- //end Navbar switcher -->
	</header>
	<!-- //Header Container  -->
    