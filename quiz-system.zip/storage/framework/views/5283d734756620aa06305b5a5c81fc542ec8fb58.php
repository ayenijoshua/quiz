<!--   ADMIN VIEW CUSTOMISE PAGE              -->



<?php $__env->startSection('title'); ?>
Customize
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customise-active'); ?>
active text-danger
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>;
<script>
     $(document).ready(function() {
     formProcessorWithCallbacks('#brand-add-form','#add-brand-btn','#brand-add-msg','Add','manage-brand','#brand-callback','.load-brands');
     formProcessorWithCallbacks('#brand-upd-form','#upd-brand-btn','#brand-upd-msg','Update','manage-brand','#brand-callback','.load-brands');
     formProcessorWithCallbacks('#brand-del-form','#del-brand-btn','#brand-del-msg','Delete','manage-brand','#brand-callback','.load-brands');
     
     formProcessorWithCallbacks('#category-add-form','#add-category-btn','#category-add-msg','Add','manage-category','#category-callback','.load-category');
     formProcessorWithCallbacks('#category-upd-form','#upd-category-btn','#category-upd-msg','Update','manage-category','#category-callback','.load-category');
     formProcessorWithCallbacks('#category-del-form','#del-category-btn','#category-del-msg','Delete','manage-category','#category-callback','.load-category');
     
     formProcessorWithCallbacks('#sub_category-add-form','#add-sub_category-btn','#sub_category-add-msg','Add','manage-sub_category','#sub_category-callback','.load-sub_category');
     formProcessorWithCallbacks('#sub_category-upd-form','#upd-sub_category-btn','#sub_category-upd-msg','Update','manage-sub_category','#sub_category-callback','.load-sub_category');
     formProcessorWithCallbacks('#sub_category-del-form','#del-sub_category-btn','#sub_category-del-msg','Delete','manage-sub_category','#sub_category-callback','.load-sub_category');
     
     formProcessorWithCallbacks('#base_category-add-form','#add-base_category-btn','#base_category-add-msg','Add','manage-base_category','#base_category-callback','.load-base_category');
     formProcessorWithCallbacks('#base_category-upd-form','#upd-base_category-btn','#base_category-upd-msg','Update','manage-base_category','#base_category-callback','.load-base_category');
     formProcessorWithCallbacks('#base_category-del-form','#del-base_category-btn','#base_category-del-msg','Delete','manage-base_category','#base_category-callback','.load-base_category');
     
     formProcessorWithFileCallbacks('#product-add-form','#add-product-btn','.product-add-msg','<i class="fa fa-check"></i> Save','manage-product','#product-callback');
     formProcessorWithFileCallbacks('#product-upd-form','#upd-product-btn','.product-upd-msg','<i class="fa fa-check"></i>Update','manage-product','#product-callback');
     //formProcessorWithCallbacks('#product-del-form','#del-product-btn','#product-del-msg','Delete','manage-product','#product-callback');
     
     formProcessorWithCallbacks('#color-add-form','#add-colour-btn','#color-add-msg','Add','manage-colour','#color-callback','.load-colours');
     formProcessorWithCallbacks('#color-upd-form','#upd-colour-btn','#color-upd-msg','Update','manage-colour','#color-callback','.load-colours');
     formProcessorWithCallbacks('#color-del-form','#del-colour-btn','#color-del-msg','Delete','manage-colour','#color-callback','.load-colours');
     
     formProcessorWithCallbacks('#size-add-form','#add-size-btn','#size-add-msg','Add','manage-size','#size-callback','.load-sizes');
     formProcessorWithCallbacks('#size-upd-form','#upd-size-btn','#size-upd-msg','Update','manage-size','#size-callback','.load-sizes');
     formProcessorWithCallbacks('#size-del-form','#del-size-btn','#size-del-msg','Delete','manage-size','#size-callback','.load-sizes');
     
     formProcessorNavWithCallbacks('#base_category-nav-form','manage-base_category','#base_category-callback');
     formProcessorNavWithCallbacks('#brand-nav-form','manage-brand','#brand-callback');
     formProcessorNavWithCallbacks('#sub_category-nav-form','manage-sub_category','#sub_category-callback');
     formProcessorNavWithCallbacks('#category-nav-form','manage-category','#category-callback');
     formProcessorNavWithCallbacks('#color-nav-form','manage-colour','#color-callback');
     formProcessorNavWithCallbacks('#size-nav-form','manage-size','#size-callback');
     
     formProcessorWithCallbacks('.manage-product-form','.manage-product-btn','.manage-product-msg',
   '<span class="fa fa-tasks"><i class="tooltip-content3">Click to update or delete.</i></span>',
   'manage-product','#load-upd-product');
   
   //formProcessorWithCallbacks('#load-del-product-form','#load-del-product-btn','#generic-modal-body','Delete This Product','manage-product');
   
   //formProcessor('#product-add-form','#add-product-btn','#product-add-msg','<i class="fa fa-check"></i> Save','manage-product','#product-callback');

     
     }); 
</script>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
<div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 ">
                        <h4 class="page-title">Settings</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12 ">
                        <ol class="breadcrumb">
                            <li><a href="#">Customize</a></li>
                            <li class="active">Shop Presentation</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
    
    
    
    <ul id="myTab" class="nav customtab nav-tabs">
<li class="nav-item active">
<a href="#landing-page"  data-toggle="tab">
Customize Landing page
</a>
</li>

<li class="nav-item">
<a href="#add-featured-cat"  data-toggle="tab">
Add Featured Categories
</a>
</li>

<li class="nav-item">
<a href="#manage-product"  data-toggle="tab">
Manage Product
</a>
</li>

<li class="nav-item">
<a href="#category"  data-toggle="tab">
Manage Categories
</a>
</li>

<li class="nav-item">
<a href="#guide"  data-toggle="tab">
How To
</a>
</li>
</ul>
    
    <div id="myTabContent" class="tab-content">
        <div class="tab-pane fade in active" id="landing-page" aria-expanded="true">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-info">
                    <div class="panel-heading"> 
                <h4 class="text-center" style="color:white;">Customize Landing Page Sliders</h4>
                    </div>
                        </div>
                    </div>
                </div>
            
            <div class="row">
                <div class="col-md-12">
                <ul id="myTab" class="nav customtab nav-tabs">
                    <li class="nav-item active">
                        <a href="#slides-list" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-list">
                            <i class=" tooltip-content3">
                                View Slider Images</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#slide-add" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-plus">
                            <i class=" tooltip-content3">
                                Add new Slide</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#slide-upd" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-edit">
                            <i class=" tooltip-content3">
                                Update Slider</i>
                        </span>
                    </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="#slide-reset" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-refresh">
                            <i class=" tooltip-content3">
                                Reset Slides to default</i>
                        </span>
                    </a>
                    </li>
                    
                    </ul> 
                
                <div id="" class="tab-content">
               <div class="tab-pane fade in active" id="slides-list" >
                   
                       <div id="slides-callback">
                          <ul class="bxslider">
                              <?=$slides_list?>
                          </ul>
                           
                           </div>
                    
                </div>
                <!--row -->
             
                <div class="tab-pane fade" id="slide-add">
                     <div id="slide-add-msg" class="text-center"></div>
                     <form id="slide-add-form" method="post" action="manage-customise" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-4">
                                <textarea class="form-control" name="slide_1_caption" placeholder="Enter caption for first slide"></textarea>           
                     <input type="file" data-default-file="panel_assets/plugins/images/chair.jpg" name="slide_1" class="upload dropify">
                            </div>
                            <div class="col-md-4">
                                <textarea class="form-control" name="slide_2_caption" placeholder="Enter caption for second slide"></textarea>
                     <input type="file" data-default-file="panel_assets/plugins/images/chair.jpg" name="slide_2" class="upload dropify">
                            </div>
                            <div class="col-md-4">
                                <textarea class="form-control" name="slide_3_caption" placeholder="Enter caption for third slide"></textarea>  
                     <input type="file" data-default-file="panel_assets/plugins/images/chair.jpg" name="slide_3" class="upload dropify">
                            </div>
                     </div>
                        <hr>
                        <div>
                             <input type="hidden" name="action" value="add-slides">
                            <button style="width:20%; " type="submit" id="slide-add-btn" class="btn btn-rounded btn-primary form-control">Add</button>
                        </div>
                       
                     </form>
                </div>
                
                <div class="tab-pane fade" id="slide-upd">
                     <div id="slide-upd-msg" class="text-center"></div>
                     <form id="slide-upd-form" method="post" action="manage-customise" enctype="multipart/form-data">
                         <?php echo e(csrf_field()); ?>

                      <div class="row">
                         <?=$slides_upd_form?>   
                     </div>
                         <hr>
                        <div>
                            <input type="hidden" name="action" value="upd-slides">
                            <button style="width:20%; " type="submit" id="slide-upd-btn" class="btn btn-rounded btn-warning form-control">Update</button>
                        </div>
                     </form>
                </div>
                
                </div>
               </div>
            </div>    
        </div>
                <!--row -->
                <div class="tab-pane fade" id="add-featured-cat">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-info">
                    <div class="panel-heading"> 
                <h4 class="text-center" style="color:white;">Add Featured Base Categories</h4>
                    </div>
                        </div>
                    <form id="add-featured-base_category-form" action="manage-base_category" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                         <label for="">Add Featured Base Categories</label>
                        <select name="feat-base_category[]" multiple="4" style="width: 100%;" class="form-control select2 load-base_category">
                            <?=$select_base_cat?>
                        </select>
                        <hr>
                        <label for="">Add Icons</label>
                        <select name="feat-base_category-fa[]" multiple="4" style="width: 100%;" class="form-control select2 load-base_category">
                            <option value="fa-female">fashion-Icon</option>
                            <option value="fa-laptop">Electronic Icon</option>
                            <option value="fa-gift">Photo&Gift Icon</option>
                            <option value="fa-home">Home Decor Icon</option>
                            <option value="fa-motorcycle">Sport Icon</option>
                        </select>
                        <input type="hidden" name="action" value="add-featured-base_category">
                        <button style="width:20%; " type="submit" id="featured-cat-add-btn" class="btn btn-rounded btn-primary form-control">Add</button>
                    </form>
                        </div>
                     
                        
                        </div>
                    
                </div>
                
                <div class="tab-pane fade" id="manage-product">
                     <ul id="myTab" class="nav customtab nav-tabs">
<li class="nav-item active">
<a href="#update-product"  data-toggle="tab">
Product Update
</a>
</li>
</ul>
                    <div class="tab-pane fade in active" id="update-product">
                  <div id="load-upd-product">
                      <p class=" bg-title">You need to select a product to be able to perform an update/delete operation</p>
                  </div>
                    </div>
                    
               
                </div>
                
                <!-- Tab for category management  -->
                <div class="tab-pane fade" id="category">
                     <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-info">
                    <div class="panel-heading"> 
                <h4 class="text-center" style="color:white;">Manage Product Brands & Categories</h4>
                    </div>
                        </div>
                    </div>
                </div>				
                    <div class="row">
                        <!-- Tab form Base category management  -->
                        <div class="col-md-6">
                    <div class="panel panel-info">
                        <div class="panel-heading"> 
                <h5 class="text-center" style="color:white;">
                    <span class="mytooltip tooltip-effect-5"> 
                        <span class="tooltip-item">Manage Base Categories</span>
                        <span class="tooltip-content clearfix"> 
                            <span class="tooltip-text text-sm" style="font-size:11px !important;">
                                Base categories are parents of sub categories. E.g,
                                Trouser has a base category of <strong><em>Fashion</em></strong>
                                and fashion has a sub category of <strong><em>Men/Women etc</em></strong>
                            </span> 
                        </span> </span>
                </h5>
                        </div>
                        <div class="panel-body">
						
                <ul id="myTab" class="nav customtab nav-tabs">
                    <li class="nav-item active">
                        <a href="#base-cat-list" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-list">
                            <i class=" tooltip-content3">
                                View list of base categories</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#base-cat-add" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-plus">
                            <i class=" tooltip-content3">
                                Add new base categories</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#base-cat-upd" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-edit">
                            <i class=" tooltip-content3">
                                Update base categories</i>
                        </span>
                    </a>
                    </li>
                    
                     <li class="nav-item">
                        <a href="#base-cat-del" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-trash">
                            <i class=" tooltip-content3">
                                Delete base categories</i>
                        </span>
                    </a>
                    </li>

                    </ul>
						
	<div id="" class="tab-content">
               <div class="tab-pane fade in active" id="base-cat-list" style="height:400px; overflow-y:scroll;">
                   <form id="base_category-nav-form" action="manage-base_category" method="post">
                       <?php echo e(csrf_field()); ?>

                       <div id="base_category-callback">
                     
                           </div>
                    </form>
                </div>
                <!--row -->
             
                <div class="tab-pane fade" id="base-cat-add">
                     <div id="base_category-add-msg" class="text-center"></div>
                    <form id="base_category-add-form" method="post" action="manage-base_category">
                        <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="base-cat-upd">
                     <div id="base_category-upd-msg" class="text-center"></div>
                     <form id="base_category-upd-form" method="post" action="manage-base_category">
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="base-cat-del">
                     <div id="base_category-del-msg" class="text-center"></div>
                     <form id="base_category-del-form" method="post" action="manage-base_category">
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                </div>
				
						</div>
				</div>
				</div>
                        <!--End Tab for Base category management  -->
                        
                        <!-- Tab form Sub category management  -->
                        <div class="col-md-6">
                    <div class="panel panel-info">
                        <div class="panel-heading"> 
                <h5 class="text-center" style="color:white;"><span class="mytooltip tooltip-effect-5"> 
                        <span class="tooltip-item">Manage Sub Categories</span>
                        <span class="tooltip-content clearfix"> 
                            <span class="tooltip-text text-sm" style="font-size:11px !important;">
                                Base categories are parents of sub categories. E.g,
                                Trouser has a base category of <strong><em>Fashion</em></strong>
                                and fashion has a sub category of <strong><em>Men/Women etc</em></strong>
                            </span> 
                        </span> </span></h5>
                        </div>
                        <div class="panel-body">
						
                <ul id="myTab" class="nav customtab nav-tabs">
                    <li class="nav-item active">
                    <a href="#sub-cat-list" class="mytooltip" data-toggle="tab">
                        <span class="fa fa-list">
                            <i class=" tooltip-content3">
                                This is a list of your product sub
                                categories.</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                    <a href="#sub-cat-add" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-plus">
                            <i class=" tooltip-content3">
                                Add new Sub categories</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                    <a href="#sub-cat-upd" class="mytooltip" data-toggle="tab">
                    <span class="fa fa-edit">
                            <i class=" tooltip-content3">
                                Update sub categories</i>
                        </span>
                    </a>
                    </li>
                    
                    <li class="nav-item">
                    <a href="#sub-cat-del" class="mytooltip" data-toggle="tab">
                    <span class="fa fa-trash">
                            <i class=" tooltip-content3">
                                Delete sub categories</i>
                        </span>
                    </a>
                    </li>

                    </ul>
						
	<div id="" class="tab-content">
               <div class="tab-pane fade in active" id="sub-cat-list" style="height:400px; overflow-y:scroll;">
                   <form id="sub_category-nav-form" method="post">
                       <?php echo e(csrf_field()); ?>

                       <div id="sub_category-callback">
                     
                           </div>
                    </form>
                </div>
                <!--row -->
             
                <div class="tab-pane fade" id="sub-cat-add">
                     <div id="sub_category-add-msg" class="text-center"></div>
                     <form id="sub_category-add-form" method="post" action="manage-sub_category">
                        <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="sub-cat-upd">
                     <div id="sub_category-upd-msg" class="text-center"></div>
                     <form id="sub_category-upd-form" method="post">
                         <?php echo e(csrf_field()); ?>

                    
                     </form>
                </div>
                
                <div class="tab-pane fade" id="sub-cat-del">
                    <div id="sub_category-del-msg" class="text-center"></div>
                     <form id="sub_category-del-form" method="post">
                         <?php echo e(csrf_field()); ?>

                    
                     </form>
                </div>
                
                </div>
				
                    </div>
                        </div>
                        </div>
                        <!-- End tab for sub category management  -->
				</div>
                         
                         <div class="row">
                              <!-- Tab form Product category management  -->
                        <div class="col-md-6">
                    <div class="panel panel-info">
                        <div class="panel-heading"> 
                <h5 class="text-center" style="color:white;">
                    <span class="mytooltip tooltip-effect-5"> 
                        <span class="tooltip-item">Manage main Categories</span>
                        <span class="tooltip-content clearfix"> 
                            <span class="tooltip-text text-sm" style="font-size:11px !important;">
                                Main categories are the immediate categories of your product. E.g,
                                Trouser has a base category of <strong><em>Fashion</em></strong>
                                and fashion has a sub category of <strong><em>Men/Women etc</em></strong>
                            </span> 
                        </span> </span>
                </h5>
                        </div>
                        <div class="panel-body">
						
                <ul id="myTab" class="nav customtab nav-tabs">
                    <li class="nav-item active">
                        <a href="#main-cat-list" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-list">
                            <i class=" tooltip-content3">
                                View list of main categories</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#main-cat-add" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-plus">
                            <i class=" tooltip-content3">
                                Add new main categories</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#main-cat-upd" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-edit">
                            <i class=" tooltip-content3">
                                Update main categories</i>
                        </span>
                    </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="#main-cat-del" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-trash">
                            <i class=" tooltip-content3">
                                Delete main categories</i>
                        </span>
                    </a>
                    </li>

                    </ul>
						
	<div id="" class="tab-content">
               <div class="tab-pane fade in active" id="main-cat-list" style="height:400px; overflow-y:scroll;">
                   <form id="category-nav-form" method="post">
                       <?php echo e(csrf_field()); ?>

                       <div id="category-callback">
                    
                       </div>
                    </form>
                </div>
                <!--row -->
             
                <div class="tab-pane fade" id="main-cat-add">
                    <div id="category-add-msg"></div>
                    <form id="category-add-form" action="manage-category" method="post">
                        <?php echo e(csrf_field()); ?>

                    
                     </form>
                </div>
                
                <div class="tab-pane fade" id="main-cat-upd">
                     <div id="category-upd-msg"></div>
                     <form id="category-upd-form" action="manage-category" method="post">
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="main-cat-del">
                    <div id="category-del-msg"></div>
                    <form id="category-del-form" method="post" action="manage-category">
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                </div>
				
						</div>
				</div>
				</div>
                        <!--End Tab for Product category management  -->
                        
                        <!-- Tab for brand management  -->
                        <div class="col-md-6">
                    <div class="panel panel-info">
                        <div class="panel-heading"> 
                <h5 class="text-center" style="color:white;"><span class="mytooltip tooltip-effect-5"> 
                        <span class="tooltip-item">Manage Brands</span>
                        <span class="tooltip-content clearfix"> 
                            <span class="tooltip-text text-sm" style="font-size:11px !important;">
                                Base categories are parents of sub categories. E.g,
                                Trouser has a base category of <strong><em>Fashion</em></strong>
                                and fashion has a sub category of <strong><em>Men/Women etc</em></strong>
                            </span> 
                        </span> </span></h5>
                        </div>
                        <div class="panel-body">
						
                <ul id="myTab" class="nav customtab nav-tabs">
                    <li class="nav-item active">
                    <a href="#brand-list" class="mytooltip" data-toggle="tab">
                        <span class="fa fa-list">
                            <i class=" tooltip-content3">
                                This is a list Brands.</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                    <a href="#brand-add" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-plus">
                            <i class=" tooltip-content3">
                                Add new Brand</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                    <a href="#brand-upd" class="mytooltip" data-toggle="tab">
                    <span class="fa fa-edit">
                            <i class=" tooltip-content3">
                                Update Brand</i>
                        </span>
                    </a>
                    </li>
                    
                    <li class="nav-item">
                    <a href="#brand-del" class="mytooltip" data-toggle="tab">
                    <span class="fa fa-trash">
                            <i class=" tooltip-content3">
                                Delete Brand</i>
                        </span>
                    </a>
                    </li>

                    </ul>
						
	<div id="" class="tab-content">
               <div class="tab-pane fade in active" id="brand-list" style="height:400px; overflow-y:scroll;">
                   <form id="brand-nav-form" action="manage-brand" method="post">
                       <?php echo e(csrf_field()); ?>

                       <div id="brand-callback">
                     
                       </div>
                    </form>
                </div>
                <!--row -->
             
                <div class="tab-pane fade" id="brand-add">
                    <form id="brand-add-form" action="manage-brand" method="post">
                        <div id="brand-add-msg" class="text-center"></div>
                        <?php echo e(csrf_field()); ?>

                    
                     </form>
                </div>
                
                <div class="tab-pane fade" id="brand-upd">
                    
                    <form id="brand-upd-form" action="manage-brand" method="post">
                         <div id="brand-upd-msg" class="text-center"></div>
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="brand-del">
                    
                    <form id="brand-del-form" action="manage-brand" method="post">
                         <div id="brand-del-msg" class="text-center"></div>
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>

                
                </div>
				
                    </div>
                        </div>
                        </div>
                        <!-- End tab for brand management  -->
                         </div>
                         
                         
                         <div class="row">
                              <!-- Tab form Product category management  -->
                        <div class="col-md-6">
                    <div class="panel panel-info">
                        <div class="panel-heading"> 
                <h5 class="text-center" style="color:white;">
                    <span class="mytooltip tooltip-effect-5"> 
                        <span class="tooltip-item">Manage Colors</span>
                        <span class="tooltip-content clearfix"> 
                            <span class="tooltip-text text-sm" style="font-size:11px !important;">
                                Main categories are the immediate categories of your product. E.g,
                                Trouser has a base category of <strong><em>Fashion</em></strong>
                                and fashion has a sub category of <strong><em>Men/Women etc</em></strong>
                            </span> 
                        </span> </span>
                </h5>
                        </div>
                        <div class="panel-body">
						
                <ul id="myTab" class="nav customtab nav-tabs">
                    <li class="nav-item active">
                        <a href="#color-list" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-list">
                            <i class=" tooltip-content3">
                                View list of colors</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#color-add" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-plus">
                            <i class=" tooltip-content3">
                                Add new color</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#color-upd" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-edit">
                            <i class=" tooltip-content3">
                                Update color</i>
                        </span>
                    </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="#color-del" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-trash">
                            <i class=" tooltip-content3">
                                Delete color</i>
                        </span>
                    </a>
                    </li>

                    </ul>
						
	<div id="" class="tab-content">
               <div class="tab-pane fade in active" id="color-list" style="height:400px; overflow-y:scroll;">
                   <form id="color-nav-form" method="post">
                       <?php echo e(csrf_field()); ?>

                       <div id="color-callback">
                     
                       </div>
                    </form>
                </div>
                <!--row -->
             
                <div class="tab-pane fade" id="color-add">
                    <div id="color-add-msg"></div>
                    <form id="color-add-form" action="manage-colour" method="post">
                        <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="color-upd">
                     <div id="color-upd-msg"></div>
                     <form id="color-upd-form" action="manage-colour" method="post">
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="color-del">
                    <div id="color-del-msg"></div>
                     <form id="color-del-form" method="post">
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                </div>
				
						</div>
				</div>
				</div>
                        <!--End Tab for Product category management  -->
                        
                        <!-- Tab for brand management  -->
                        <div class="col-md-6">
                    <div class="panel panel-info">
                        <div class="panel-heading"> 
                <h5 class="text-center" style="color:white;"><span class="mytooltip tooltip-effect-5"> 
                        <span class="tooltip-item">Manage Sizes</span>
                        <span class="tooltip-content clearfix"> 
                            <span class="tooltip-text text-sm" style="font-size:11px !important;">
                                Base categories are parents of sub categories. E.g,
                                Trouser has a base category of <strong><em>Fashion</em></strong>
                                and fashion has a sub category of <strong><em>Men/Women etc</em></strong>
                            </span> 
                        </span> </span></h5>
                        </div>
                        <div class="panel-body">
						
                <ul id="myTab" class="nav customtab nav-tabs">
                    <li class="nav-item active">
                    <a href="#size-list" class="mytooltip" data-toggle="tab">
                        <span class="fa fa-list">
                            <i class=" tooltip-content3">
                                This is a list of sizes.</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                    <a href="#size-add" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-plus">
                            <i class=" tooltip-content3">
                                Add new size</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                    <a href="#size-upd" class="mytooltip" data-toggle="tab">
                    <span class="fa fa-edit">
                            <i class=" tooltip-content3">
                                Update size</i>
                        </span>
                    </a>
                    </li>
                    
                    <li class="nav-item">
                    <a href="#size-del" class="mytooltip" data-toggle="tab">
                    <span class="fa fa-trash">
                            <i class=" tooltip-content3">
                                Delete size</i>
                        </span>
                    </a>
                    </li>

                    </ul>
						
	<div id="" class="tab-content">
               <div class="tab-pane fade in active" id="size-list" style="height:400px; overflow-y:scroll;">
                   <form id="size-nav-form" action="manage-size" method="post">
                       <?php echo e(csrf_field()); ?>

                       <div id="size-callback">
                    
                       </div>
                    </form>
                </div>
                <!--row -->
             
                <div class="tab-pane fade" id="size-add">
                    <form id="size-add-form" action="manage-size" method="post">
                        <div id="size-add-msg" class="text-center"></div>
                        <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="size-upd">
                    
                    <form id="size-upd-form" action="" method="post">
                         <div id="size-upd-msg" class="text-center"></div>
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>
                
                <div class="tab-pane fade" id="size-del">
                    
                    <form id="size-del-form" action="" method="post">
                         <div id="size-del-msg" class="text-center"></div>
                         <?php echo e(csrf_field()); ?>

                     
                     </form>
                </div>

                
                </div>
				
                    </div>
                        </div>
                        </div>
                        <!-- End tab for brand management  -->
                         </div>
                         
			</div>	     
                </div>
                
                </div>
                <!-- End tab for category management -->
               
                
            </div>
 </div>

</div>
            <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>