<!-- Footer Container -->
	<footer class="footer-container type_footer5">
		
		<!-- Footer Top Container -->
		<section class="footer-top">
			<div class="container content">
				<div class="row">
					<div class="col-md-12">
						<div class="module clearfix ">
							<div class="modcontent">
								<div class="block-policy-top ">
									<div class="policy policy1 col-sm-4 col-xs-12">
										<div class="policy-inner">
											<i class="ico-policy"></i>
											<h4>30 days return</h4>
											<span>Money back guarantee</span>
										</div>
									</div>
									<div class="policy policy2 col-sm-4 col-xs-12">
										<div class="policy-inner">
										<i class="ico-policy"></i>
										<h4>free shipping on $30</h4>
										<span>on all orders over $99</span>
										</div>
									</div>
									<div class="policy policy3 col-sm-4 col-xs-12">
										<div class="policy-inner">
										<i class="ico-policy"></i>
										<h4>Safe shopping</h4>
										<span>Save up to 50% now  </span>
										</div>
									</div>
									
								</div>
							</div>
						</div>
					</div>
					
					
				</div>
			</div>
		</section>
		<!-- /Footer Top Container -->
		
		<section class="footer-center">
			<div class=" container">
				<div class="row">
					<div class="module clearfix modLine icons-social">
						<h3 class="modtitle">Follow Us</h3>
						<div class="modcontent">
							<div class="list-inline">
								<a title="Facebook" href="http://www.facebook.com/MagenTech" target="_blank"> 
									<span class="fa fa-facebook icon-circled icon-color"></span> 
								</a>
							
								<a title="Twitter" href="https://twitter.com/magentech" target="_blank"> 
									<span class="fa fa-twitter icon-circled icon-color"></span> 
								</a>
						
								<a title="Google+" href="https://plus.google.com/u/0/+Smartaddons" target="_blank"> 
									<span class="fa fa-google-plus icon-circled icon-color"></span>
								</a>
							
								
								<a title="Pinterest" href="#" target="_blank"> 
									<span class="fa fa-instagram icon-circled icon-color"></span>
								</a>
								
								
							</div>
							
						</div>
					</div>
					<hr class="footer-lines ">
					<div class="col-sm-6 col-md-3 box-information">
						<div class="module clearfix">
							<h3 class="modtitle">Information</h3>
							<div class="modcontent">
								<ul class="menu">
									<li><a href="about-us.html">About Us</a></li>
									<li><a href="faq.html">FAQ</a></li>
									<li><a href="order-history.html">Order history</a></li>
									<li><a href="order-information.html">Order information</a></li>
								</ul>
							</div>
						</div>
					</div>

					<div class="col-sm-6 col-md-3 box-service">
						<div class="module clearfix">
							<h3 class="modtitle">Customer Service</h3>
							<div class="modcontent">
								<ul class="menu">
									<li><a href="contact.html">Contact Us</a></li>
									<li><a href="return.html">Returns</a></li>
									<li><a href="sitemap.html">Site Map</a></li>
									<li><a href="my-account.html">My Account</a></li>
								</ul>
							</div>
						</div>
					</div>

					<div class="col-sm-6 col-md-3 box-account">
						<div class="module clearfix">
							<h3 class="modtitle">My Account</h3>
							<div class="modcontent">
								<ul class="menu">
									<li><a href="#">Brands</a></li>
									<li><a href="gift-voucher.html">Gift Vouchers</a></li>
									<li><a href="#">Affiliates</a></li>
									<li><a href="#">Specials</a></li>
									<li><a href="#" target="_blank">Our Blog</a></li>
								</ul>
							</div>
						</div>
					</div>

					<div class="col-sm-6 col-md-3 collapsed-block ">
						<div class="module clearfix">
							<h3 class="modtitle">Contact Us	</h3>
							<div class="modcontent">
								<ul class="contact-address">
									<li><span class="fa fa-map-marker"></span> My Company, 42 avenue des Champs Elysées 75000 Paris France</li>
									<li><span class="fa fa-envelope-o"></span> Email: <a href="#"> sales@yourcompany.com</a></li>
									<li><span class="fa fa-phone">&nbsp;</span> Phone 1: 0123456789 <br>Phone 2: (123) 4567890</li>
								</ul>
							</div>
						</div>
					</div>
					
					<hr class="footer-lines no-margin-bottom">
				</div>
			</div>	
		</section>
		
		<!-- Footer Bottom Container -->
		<div class="footer-bottom-block ">
			<div class=" container">
				<div class="row">
					<div class="col-sm-5 copyright-text"> © 2016 Market. All Rights Reserved. </div>
					<div class="col-sm-7">
						<div class="block-payment text-right"><img href="assets/image/demo/content/payment.png" alt="payment" title="payment" ></div>
					</div>
					<!--Back To Top-->
					<div class="back-to-top"><i class="fa fa-angle-up"></i><span> Top </span></div>

				</div>
			</div>
		</div>
		<!-- /Footer Bottom Container -->
		
		
	</footer>
	<!-- //end Footer Container -->
        
         <div class="modal fade" style="" id="genericModal" tabindex="-1" role="dialog"
aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close"
data-dismiss="modal" aria-hidden="true">
&times;
</button>
<h4 class="modal-title text-center" id="myModalLabel">

</h4>
</div>
       <div id="staff_upd_results" class="text-center"></div>
       <div class="modal-body generic-modal-body" id="generic-modal-body">
           
            </div>
        </div>
   </div>

</div>
</div>
        
	
<link rel='stylesheet' property='stylesheet'  href='assets/css/themecss/cpanel.css' type='text/css' media='all' />
<!-- Include Libs & Plugins
============================================ -->
<!-- Placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="assets/js/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/js/owl-carousel/owl.carousel.js"></script>
<script type="text/javascript" src="assets/js/themejs/libs.js"></script>
<script type="text/javascript" src="assets/js/unveil/jquery.unveil.js"></script>
<script type="text/javascript" src="assets/js/countdown/jquery.countdown.min.js"></script>
<script type="text/javascript" src="assets/js/dcjqaccordion/jquery.dcjqaccordion.2.8.min.js"></script>
<script type="text/javascript" src="assets/js/datetimepicker/moment.js"></script>
<script type="text/javascript" src="assets/js/datetimepicker/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="assets/js/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="assets/js/modernizr/modernizr-2.6.2.min.js"></script>


<!-- Theme files
============================================ -->
<script type="text/javascript" src="assets/js/themejs/application.js"></script>
<script type="text/javascript" src="assets/js/themejs/homepage.js"></script>
<script type="text/javascript" src="assets/js/themejs/so_megamenu.js"></script>
<script type="text/javascript" src="assets/js/themejs/addtocart.js"></script>	
<script type="text/javascript" src="assets/js/themejs/pathLoader.js"></script>	
<!--<script type="text/javascript" src="assets/js/themejs/toppanel.js"></script>-->
<script type="text/javascript" src="assets/js/minicolors/jquery.miniColors.min.js"></script>

<script type="text/javascript">

var $typeheader = 'header-home8';
//-->
</script>	
	
		<script>
var modal = {
// Checks for a modal window and returns it, or
// else creates a new one and returns that
"initModal_nofade" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-window").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-window")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-window");
}
},

"initModal_result" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-result").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-result")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-result");
}
},

"initModal_add_profile" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-add-profile").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-add-profile")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-add-profile");
}
},

"initModal_fade" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-window-fade").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-window-fade")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-window");
}
},

"close_btn" : function(modal_var){
    $("<a>")
.attr("href", "#")
.addClass("modal-close-btn")
.html("&times;")
.click(function(event){
// Prevent the default action
event.preventDefault();
// Removes modal window
modal.boxout(event);
$("div").remove(".modal-overlay");
$("div").remove(".modal-overlay-result");
})
.appendTo(modal_var);
},

"close_result_btn" : function(modal_var){
    $("<a>")
.attr("href", "#")
.attr("data-toggle","modal")
.attr("data-target","#close-result-modal")
.addClass("modal-close-btn")
.html("&times;")
.appendTo(modal_var);
},

// Adds the window to the markup and fades it in
"boxin_fade" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
modal.boxout(event);
})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-window-fade,.modal-overlay")
.fadeIn(2000)
.fadeOut(5000);
},

// Adds the window to the markup and fades it in
"boxin_nofade" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
//modal.boxout(event);
modal.close_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-window,.modal-overlay")
.fadeIn(2000);

},

"boxin_add_profile" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
//modal.boxout(event);
modal.close_result_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element

modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-add-profile,.modal-overlay")
.fadeIn(1000);
},

"boxin_result" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay-result")
.click(function(event){
// Removes event
modal.close_result_btn(modal_var);
//modal.close_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-result,.modal-overlay-result")
.fadeIn(1000);

},

        
// Fades out the window and removes it from the DOM
"boxout" : function(event) {
// If an event was triggered by the element
// that called this function, prevents the
// default action from firing
if ( event!==undefined )
{
event.preventDefault();
}
// Removes the active class from all links
$("a").removeClass("active");
// Fades out the modal window, then removes
// it from the DOM entirely
$(".modal-window,.modal-add-profile, .modal-result")
.fadeOut("slow", function() {
$(this).remove();
}
);
}
};

//function to remove modal for close href in result modal
$(document).on('click','#close-result',function(e){
    modal.boxout(e);
$("div").remove(".modal-overlay");
$("div").remove(".modal-overlay-result");
});


function loginProcessor(form_id,login_btn,notification,url,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                var btn = $(login_btn);
                var info = $(notification);

                 $.ajaxSetup(
                        {
                                beforeSend: function()
                                {
                                        btn.attr("disabled",true);
                                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+"Authenticating... </span>");
                                },
                                complete: function()
                                {
                                        btn.attr("disabled",false);
                                        btn.html( "Login!");
                                }
                        });
                       
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(login_btn).html('Login');
                                      $(info).html("<div class=\"error\">"+res.text+"</div>");
                                }
                                if(res.type === "done"){
                                    $(info).html("<div class=\"success\">!!Success Please Wait.</div>");
                                     $(login_btn).html('Login');
                                     redirect(val);
                                     window.setTimeout(function(){
                                     window.location.href = res.text;     
                                     }, 3000);
                                }
                        });
                    });
                } 
                
     function formProcessorWithCallbacks(form_id,submit_btn,notification,return_text,url,callback_selector,mass_load_selector,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                var mass_loader = $(mass_load_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        info.html("<span style='color:#fff'>"+loader_gif.LARGE+" </span>");
                        //load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error text-center\"> "+res.text+"</div>");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //load_body.html(res.content);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    return false;
                                    e.stopPropagation();
                                    //redirect(val);
                                }
                                
                                if(res.type === "done"){
                                    
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    mass_loader.html(res.mass_load);
                                    //loop(res);
                                   redirect(val);
                                   return false;
                                   e.stopImmediatePropagation();
                                }
                        });
                    });
                }
     function formProcessorNavWithCallbacks(form_id,url,callback_selector){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                //var btn = $(submit_btn);
                //var info = $(notification);
                var load_body = $(callback_selector);
                 
                        load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //btn.html(return_text);
                                     //btn.attr("disabled",false);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    //return false;
                                    event.stopPropagation();
                                    //redirect(val);
                                }
                                if(res.type === "done"){
                                   // info.html("<div class=\"success\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    //btn.attr("disabled",false);
                                    //btn.html(return_text);
                                    load_body.html(res.content);
                                    //redirect(val);
                                   //return false;
                                   event.stopImmediatePropagation();
                                }
                        });
                    });
                }   
     function formProcessorWithFileCallbacks(form_id,submit_btn,notification,return_text,url,callback_selector,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = new FormData(this);
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false,
                                contentType: false,
                                processData:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error text-center\">Error!! "+res.text+"</div>");
                                     //$(notification).delay(10000).fadeOut("fast");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    //redirect(val);
                                    return false;
                                    event.stopPropagation();
                                    
                                }
                                if(res.type === "done"){
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    redirect(val);
                                   //return false;
                                   event.stopImmediatePropagation();
                                }
                        });
                    });
                }           
    function redirect($var){
        if($var===true){
            document.location.href = document.location;
        }
        if($var==='logout'){
            document.location.href = 'home';
        }
        if($var==='checkout'){
            document.location.href = 'checkout';
        }
        if($var==='invoice'){
            document.location.href = 'invoice';
        }
        if($var===''){
            
        }
    } 
            
     function cartProcessor(form_id,button,url,cart_callback,callback2)
    {
        var btn_val = $(button).html(); 
        $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
                
            var request_method = $(this).attr("method"); //get form GET/POST method
            var form_data = new FormData(this); //Creates new FormData object

            $(button).html(loader_gif.SMALLER);
             $(button).attr("disabled",true);
            $.ajax({ //ajax form submit
                    url :url,
                    type: request_method,
                    data : form_data,
                    dataType : "json",
                    contentType: false,
                    cache: false,
                    processData:false
            }).done(function(res){ //fetch server "json" messages when done
                    if(res.type === "error"){
                         modal.boxin_nofade('<div class="error">'+ res.text +"</div>",modal.initModal_nofade());
                         window.setTimeout(function(){
                         $(button).html(btn_val);
                          //$("div").remove(".modal-overlay");
                          $(button).attr("disabled",false);
                         }, 2000);
                         return false;
                    }
                    if(res.type === "done"){
                         $("div").remove(".modal-window-fade");
                        modal.boxin_fade('<div class="success">'+ res.text +"</div>",modal.initModal_fade());
                        $(cart_callback).html(res.content);
                        $(callback2).html(res.mass_load);
                         window.setTimeout(function(){
                         $(button).html(btn_val);
                         $("div").remove(".modal-overlay");
                         $(button).attr("disabled",false);
                         }, 2000);
                         return false;
                    }
            });
                
        });
    }  
     
   function formProcessor(form_id,submit_btn,notification,return_text,url,callback_selector,mass_load_selector,val){
     $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = new FormData(this);
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                var mass_loader = $(mass_load_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        info.html("<span style='color:#fff'>"+loader_gif.LARGE+" </span>");
                        //load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false,
                                contentType: false,
                                processData:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error\"> "+res.text+"</div>");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //load_body.html(res.content);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    return false;
                                    e.stopPropagation();
                                    //redirect(val);
                                }
                                
                                if(res.type === "done"){
                                    
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    mass_loader.html(res.mass_load);
                                    //loop(res);
                                    //redirect(val);
                                    e.stopImmediatePropagation();
                                   return false;
                                   
                                }
                        });
                    });
      
}
       
      
   function ajaxNav(click_id,offs,upd_body,url){
             $(document).on('click',click_id, function(e){
                e.preventDefault(); 
            var offset = $(this).find(offs).val();
           $.ajax({
              url:url,
              method:"POST",
              data:{action:click_id,offset:offset},
              dataType:"text",
              success:function(data){
                  $(upd_body).html(data);
              }
           });
        });    
  }
  
  function fetchSearchData(form_id,obj_cat,upd_body,url)
  {
      $(document).on('submit',form_id,function(e){
          e.preventDefault();
    var border_color = "#C2C2C2";
    var alpha_num = /^[a-zA-Z]{15}$/i;
    
	proceed = true;
	
	//simple input validation
	var search_box = $(this).find("#users-search");
        
            if(!$.trim(search_box.val())){ //if this field is empty 
                $(this).css('border-color','red'); //change border color to red   
                proceed = false; //set do not proceed flag
            }else{
		 $(this).css('border-color', border_color);
                 proceed = true;
            }
            
            if(proceed){
               var input_value = $(this).find('#users-search').val();
               input_value.replace(/\W/g, '');
               //alert(input_value);
               var action = $(this).find('#action').val();
               var search_by = $(this).find('#search-by').val();
               $(upd_body).html(loader_gif.LARGER);
               $('#users-search').attr('disabled',true);
               $('#search-submit-btn').attr('disabled',true);
                $.ajax({
              url:url,
              method:"POST",
              dataType:"text",
              data:{input_value:input_value,search_by:search_by,obj_cat:obj_cat,action:action},
               success:function(data){
              $(upd_body).html(data);
              $('#users-search').attr('disabled',false);
              $('#search-submit-btn').attr('disabled',false);
              }
        });
            }
      });
  
  
  }
  
  function fetch_selectsearch_obj(obj,input_id,search_by,obj_cat,upd_body,url)
         {
             $(document).on('input',input_id, function(){ 
           var input = $(input_id).val();
           
           $(upd_body).html('<option value="name">.....Loading....</option>');
           //alert(input);
           $.ajax({
              url: url,
              method:"POST",
              data:{search_obj:obj,input_value:input,search_by:search_by,obj_cat:obj_cat},
              dataType:"text",
              success:function(data){
                  $(upd_body).html(data); 
              }
           });
            
        });    
  }
  function showPopulateContainer(obj,obj_cat,url){
    $(document).on('input',obj,function(){
        
       var par = $(this).parent('#search-form');
       par.find('#search-submit-btn').removeAttr('disabled');
       par.find('#populate-container').css('display','block'); 
       //obj.replace(/\W/g,'');
       var search_by = par.find('#search-by').val();
        var upd_body = par.find('#populate-select');
      fetch_selectsearch_obj(obj,obj,search_by,obj_cat,upd_body,url);
    }).on('blur','#populate-select',function(){
        var par = $(this).parents('#search-form');
        //par.find('#search-submit-btn').attr('disabled','disabled');
        par.find('#populate-container').css('display','none');
    }).on('click','#populate-select',function(){
        var par = $(this).parents('#search-form');
        var split = $(this).val().split(" ");
        par.find(obj).val(split[0]) ;//search_box.val().replace(/\W/g,'');
    });
}



var loader_gif = {
     "SMALL" : "<div class=\"text-center\"> <img width=\"30px\" height=\"30px\" src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>",
    "SMALLER" : "<div class=\"pull-left\"> <img style=\"display:inline\" width=\"20px\" height=\"20px\" src=\"assets/img/spinner.gif\"/>\n\</div>",
    "LARGE": "<div class=\"text-center\"> <img width=\"50px\" height=\"50px\" src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>",
    "LARGER": "<div class=\"text-center\"> <img src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>" 
    
};
  
		</script>
	
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster --> 
</body>
</html>