<!--   ADMIN VIEW CUSTOMISE PAGE              -->



<?php $__env->startSection('title'); ?>
Customize
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customise-active'); ?>
active text-danger
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
     $(document).ready(function() {
     formProcessorWithCallbacks('#add-colour-form','#add-colour-btn','#add-colours-msg','Add/Update','manage-customise','','');
     formProcessorWithCallbacks('#colour-reset-form','#colour-reset-btn','#add-colours-msg','Reset','manage-customise','','');
     
     formProcessorWithCallbacks('#add-layout-form','#add-layout-btn','#add-layout-msg','Add/Update','manage-customise','','');
     formProcessorWithCallbacks('#layout-reset-form','#layout-reset-btn','#add-layout-msg','Reset','manage-customise','','');
     
     formProcessorWithFileCallbacks('#slide-add-form','#slide-add-btn','.slide-add-msg','Add','manage-customise','');
     formProcessorWithFileCallbacks('#slide-upd-form','#slide-upd-btn','.slide-upd-msg','Update','manage-customise','');
     formProcessorWithFileCallbacks('#slide-reset-form','#slide-upd-btn','.slide-upd-msg','Reset','manage-customise','');
     
     }); 
</script>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
<div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 ">
                        <h4 class="page-title">Settings</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12 ">
                        <ol class="breadcrumb">
                            <li><a href="#">Customize</a></li>
                            <li class="active">Shop Presentation</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
    
    <ul id="myTab" class="nav customtab nav-tabs">
<li class="nav-item active">
<a href="#landing-page"  data-toggle="tab">
Manage Sliders
</a>
</li>

<li class="nav-item">
<a href="#manage-settings"  data-toggle="tab">
Manage Template Settings
</a>
</li>

<li class="nav-item">
<a href="#guide"  data-toggle="tab">
How To
</a>
</li>
</ul>
    
    <div id="myTabContent" class="tab-content">
        <div class="tab-pane fade in active" id="landing-page" aria-expanded="true">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-info">
                    <div class="panel-heading"> 
                <h4 class="text-center" style="color:white;">Customize Landing Page Sliders</h4>
                    </div>
                        </div>
                    </div>
                </div>
            
            <div class="row">
                <div class="col-md-12">
                <ul id="myTab" class="nav customtab nav-tabs">
                    <li class="nav-item active">
                        <a href="#slides-list" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-list">
                            <i class=" tooltip-content3">
                                View Slider Images</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#slide-add" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-plus">
                            <i class=" tooltip-content3">
                                Add new Slide</i>
                        </span>
                    </a>
                    </li>

                    <li class="nav-item">
                        <a href="#slide-upd" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-edit">
                            <i class=" tooltip-content3">
                                Update Slider</i>
                        </span>
                    </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="#slide-reset" class="mytooltip"  data-toggle="tab">
                    <span class="fa fa-refresh">
                            <i class=" tooltip-content3">
                                Reset Slides to default</i>
                        </span>
                    </a>
                    </li>
                    
                    </ul> 
                
                <div id="" class="tab-content">
               <div class="tab-pane fade in active" id="slides-list" >
                   
                       <div id="slides-callback">
                          <ul class="bxslider">
                              <?=$slides_list?>
                          </ul>
                           
                           </div>
                    
                </div>
                <!--row -->
             
                <div class="tab-pane fade" id="slide-add">
                     <div id="slide-add-msg" class="text-center"></div>
                     <form id="slide-add-form" method="post" action="manage-customise" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="slide-add-msg"></div>
                            <div class="col-md-4">
                                <textarea class="form-control" name="slide_1_caption" placeholder="Enter caption for first slide"></textarea>           
                     <input type="file" data-default-file="panel_assets/plugins/images/chair.jpg" name="slide_1" class="upload dropify">
                            </div>
                            <div class="col-md-4">
                                <textarea class="form-control" name="slide_2_caption" placeholder="Enter caption for second slide"></textarea>
                     <input type="file" data-default-file="panel_assets/plugins/images/chair.jpg" name="slide_2" class="upload dropify">
                            </div>
                            <div class="col-md-4">
                                <textarea class="form-control" name="slide_3_caption" placeholder="Enter caption for third slide"></textarea>  
                     <input type="file" data-default-file="panel_assets/plugins/images/chair.jpg" name="slide_3" class="upload dropify">
                            </div>
                        </div>
                        <hr>
                        <div>
                             <input type="hidden" name="action" value="add-slides">
                            <button style="width:20%; " type="submit" id="slide-add-btn" class="btn btn-rounded btn-primary form-control">Add</button>
                        </div>
                       
                     </form>
                </div>
                
                <div class="tab-pane fade" id="slide-upd">
                     <div id="slide-upd-msg" class="text-center"></div>
                     <form id="slide-upd-form" method="post" action="manage-customise" enctype="multipart/form-data">
                         <?php echo e(csrf_field()); ?>

                         <div class="slide-upd-msg"></div>
                      <div class="row">
                         <?=$slides_upd_form?>   
                     </div>
                         <hr>
                        <div>
                            <input type="hidden" name="action" value="upd-slides">
                            <button style="width:20%; " type="submit" id="slide-upd-btn" class="btn btn-rounded btn-warning form-control">Update</button>
                        </div>
                     </form>
                </div>
                
                </div>
               </div>
            </div>    
        </div>
                <!--row -->
                <div class="tab-pane fade" id="manage-settings">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-info">
                    <div class="panel-heading"> 
                <h4 class="text-center" style="color:white;">Manage Template Colours</h4>
                    </div>
                        </div>
                    <ul id="myTab" class="nav customtab nav-tabs">
<li class="nav-item active">
<a href="#add-colours"  data-toggle="tab">
Add/Update Colours
</a>
</li>

<li class="nav-item">
<a href="#guide"  data-toggle="tab">
guide
</a>
</li>

</ul>
                        <div id="" class="tab-content">
                             <div class="tab-pane fade in active" id="add-colours">
                                 <div id="" class="table table-responsive">
                                     <h4 class="text-center">Define Template Colours</h4>
                                     <form id="add-colour-form" action="manage-customise" method="post">
                                          <?php echo e(csrf_field()); ?>

                                          <input type="hidden" name="action" value="add-bgc">
                                  <table class="table table-hover">
                                      <caption id="add-colours-msg"></caption>
                                      <tr>
                                          <td>Header center Background Colour</td> <td><input type="color" style="width: 100%" class="form-control" name="header-center-bgc" ></td>
                                      </tr>
                                      <tr>
                                          <td>Header bottom Background Colour</td> <td><input type="color" style="width: 100%" class="form-control" name="header-bottom-bgc" ></td>
                                      </tr>
                                      <tr>
                                          <td>Footer Background Colour</td> <td><input type="color" style="width: 100%" class="form-control" name="footer-bgc" ></td>
                                      </tr>
                                      <tr>
                                          <td>Site Colour</td> <td><input type="color" style="width: 100%" class="form-control" name="site-colour" ></td>
                                      </tr>
                                      <tr>
                                          <td><button id="add-colour-btn" type="submit" style="width: 100%" class="form-control btn-success">Add/Update</button></td>
                                      </tr>
                                      <hr>
                                  </table>
                              </form>
                                     <form class="" id="colour-reset-form" action="manage-customise" method="post">
                                         <?php echo e(csrf_field()); ?>

                                  <input type="hidden" name="action" value="colour-reset">
                                  <button id="colour-reset-btn" type="submit" class="btn btn-primary">Reset to default</button>
                              </form>
                          </div>
                            </div>
                           
                            <div class="tab-pane fade in " id="guid">
                          <div id="">

                          </div>
                            </div>
                        </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="panel panel-info">
                    <div class="panel-heading"> 
                <h4 class="text-center" style="color:white;">Manage Template Layout</h4>
                    </div>
                        </div>
                    <ul id="myTa" class="nav customtab nav-tabs">
<li class="nav-item active">
<a href="#add-bg"  data-toggle="tab">
Add/Update layout
</a>
</li>

<li class="nav-item">
<a href="#view-bg"  data-toggle="tab">
View Background images
</a>
</li>

<li class="nav-item">
<a href="#bg-guide"  data-toggle="tab">
Guide
</a>
</li>

</ul>
                        <div id="" class="tab-content">
                            <div class="tab-pane fade in active" id="add-bg">
                                 <div id="" class="table table-responsive">
                                     <h4 class="text-center">Define Template Layout</h4>
                                     <form id="add-layout-form" action="manage-customise" method="post">
                                         <?php echo e(csrf_field()); ?>

                                         <input type="hidden" name="action" value="add-layout">
                                  <table class="table table-hover" cellpadding="8px" method="post">
                                      <caption id="add-layout-msg"></caption>
                                      <tr>
                                          <td>Template layout</td> <td>
                                              <select style="width: 100%" class="form-control select2" name="site-layout">
                                                  <option value="0">Select a layout</option>
                                                  <option value="wrapper-rounded">Rounded</option>
                                                  <option value="wrapper-boxed">Boxed</option>
                                                  <option value="wrapper-iframed">Framed</option>
                                              </select>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>Template Background</td> <td>
                                            <select style="width: 100%" class="form-control select2" name="site-bg-img">
                                                  <option value="0">Select a Background Image</option>
                                                  <option value="bg-imgs/fabric1.png">Fabric 1</option>
                                                  <option value="bg-imgs/fabric2.png">Fabric 2</option>
                                                  <option value="bg-imgs/fabric3.png">Fabric 3</option>
                                                  <option value="bg-imgs/fabric4.png">Fabric 4</option> 
                                                  <option value="bg-imgs/fabric5.png">Fabric 5</option>
                                                  <option value="bg-imgs/fabric6.png">Fabric 6</option>
                                                  <option value="bg-imgs/fabric7.png">Fabric 7</option>
                                                  <option value="bg-imgs/fabric8.png">Fabric 8</option>
                                                  <option value="bg-imgs/fabric9.png">Fabric 9</option>
                                                  <option value="bg-imgs/wood1.png">Wood 1</option>
                                                  <option value="bg-imgs/wood2.png">Wood 2</option>
                                                  <option value="bg-imgs/wood3.png">Wood 3</option>
                                            </select>  
                                          </td>
                                      </tr>
                                      
                                      <tr>
                                          <td><button id="add-layout-btn" type="submit" style="width: 100%" class="form-control btn-success">Add/Update</button></td>
                                      </tr>
                                      <hr>
                                  </table>
                              </form>
                                <form class="" id="layout-reset-form" action="manage-customise" method="post">
                                         <?php echo e(csrf_field()); ?>

                                  <input type="hidden" name="action" value="layout-reset">
                                  <button id="layout-reset-btn" type="submit" class="btn btn-primary">Reset to default</button>
                                </form>
                          </div>
                            </div>
                            
                            <div class="tab-pane fade in " id="view-bg">
                                <div class="table table-responsive">
                                    <h4 class="text-center">View Available background Images</h4>
                                    <hr>
                                <table class="table table-hover table-responsive">
                                    <tr>
                                        <th>Fabric1</th><th>Fabric2</th><th>Fabric3</th><th>Fabric4</th><th>Fabric5</th><th>Fabric6</th>    
                                    </tr>
                                    <tr>
                                        <td><img src="bg-imgs/fabric1.png"></td>
                                        <td><img src="bg-imgs/fabric2.png"></td>
                                        <td><img src="bg-imgs/fabric3.png"></td>
                                        <td><img src="bg-imgs/fabric4.png"></td>
                                        <td><img src="bg-imgs/fabric5.png"></td>
                                        <td><img src="bg-imgs/fabric6.png"></td>    
                                    </tr>
                                    <tr>
                                        <th>Fabric7</th><th>Fabric8</th><th>Fabric9</th><th>Wood1</th><th>Wood2</th><th>Wood3</th>    
                                    </tr>
                                    <tr>
                                        <td><img src="bg-imgs/fabric7.png"></td>
                                        <td><img src="bg-imgs/fabric8.png"></td>
                                        <td><img src="bg-imgs/fabric9.png"></td>
                                        <td><img src="bg-imgs/wood1.png"></td>
                                        <td><img src="bg-imgs/wood2.png"></td>
                                        <td><img src="bg-imgs/wood3.png"></td>    
                                    </tr>
                                </table> 
                                </div>    
                            </div>
                            
                            <div class="tab-pane fade in " id="layout-guide">
                          <div id="">

                          </div>
                            </div>
                        </div>
                        </div>
                    
                    </div>
                    
                    
                </div>
                
                
                
                </div>
                <!-- End tab for category management -->
               
                
            </div>
 </div>

</div>
            <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>