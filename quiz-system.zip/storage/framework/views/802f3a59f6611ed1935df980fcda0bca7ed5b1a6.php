<!-- //subscribe --> 
	<!-- footer -->
	<div class="footer hidden-print">
		<div class="container">
			<div class="footer-info w3-agileits-info">
				<div class="col-md-4 address-left agileinfo">
					<div class="footer-logo header-logo">
						<h2><a href="index.html"><span>S</span>mart <i>Bazaar</i></a></h2>
						<h6>Your stores. Your place.</h6>
					</div>
					<ul>
						<li><i class="fa fa-map-marker"></i> 123 San Sebastian, New York City USA.</li>
						<li><i class="fa fa-mobile"></i> 333 222 3333 </li>
						<li><i class="fa fa-phone"></i> +222 11 4444 </li>
						<li><i class="fa fa-envelope-o"></i> <a href="mailto:example@mail.com"> mail@example.com</a></li>
					</ul> 
				</div>
				<div class="col-md-8 address-right">
					<div class="col-md-4 footer-grids">
						<h3>Company</h3>
						<ul>
							<li><a href="about.html">About Us</a></li>
							<li><a href="marketplace.html">Marketplace</a></li>  
							<li><a href="values.html">Core Values</a></li>  
							<li><a href="privacy.html">Privacy Policy</a></li>
						</ul>
					</div>
					<div class="col-md-4 footer-grids">
						<h3>Services</h3>
						<ul>
							<li><a href="contact.html">Contact Us</a></li>
							<li><a href="login.html">Returns</a></li> 
							<li><a href="faq.html">FAQ</a></li>
							<li><a href="sitemap.html">Site Map</a></li>
							<li><a href="login.html">Order Status</a></li>
						</ul> 
					</div>
					<div class="col-md-4 footer-grids">
						<h3>Payment Methods</h3>
						<ul>
							<li><i class="fa fa-laptop" aria-hidden="true"></i> Net Banking</li>
							<li><i class="fa fa-money" aria-hidden="true"></i> Cash On Delivery</li>
							<li><i class="fa fa-pie-chart" aria-hidden="true"></i>EMI Conversion</li>
							<li><i class="fa fa-gift" aria-hidden="true"></i> E-Gift Voucher</li>
							<li><i class="fa fa-credit-card" aria-hidden="true"></i> Debit/Credit Card</li>
						</ul>  
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
        
         <div class="modal fade" style="" id="genericModal" tabindex="-1" role="dialog"
aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close"
data-dismiss="modal" aria-hidden="true">
&times;
</button>
<h4 class="modal-title text-center" id="myModalLabel">

</h4>
</div>
       <div id="staff_upd_results" class="text-center"></div>
       <div class="modal-body generic-modal-body" id="generic-modal-body">
           
            </div>
        </div>
   </div>

</div>
      
        
	<!-- //footer -->		
	<div class="copy-right"> 
		<div class="container">
			<p>© 2016 Smart bazaar . All rights reserved | Design by <a href="http://w3layouts.com"> W3layouts.</a></p>
		</div>
	</div> 
	<!-- cart-js -->
	<script src="<?php echo e(URL::asset('assets/js/minicart.js')); ?>"></script>
        <script src="panel_assets/plugins/bxslider/js/jquery.bxslider.js"></script>
	<script>
        w3ls.render();
        $('.bxslide').bxSlider({
        auto: true,
        mode: 'fade',
        autoControls: false,
        stopAutoOnClick:false,
        pager: false
        
    });
        w3ls.cart.on('w3sb_checkout', function (evt) {
        	var items, len, i;

        	if (this.subtotal() > 0) {
        		items = this.items();

        		for (i = 0, len = items.length; i < len; i++) {
        			items[i].set('shipping', 0);
        			items[i].set('shipping2', 0);
        		}
        	}
        });
    </script>  
	<!-- //cart-js -->	
	<!-- countdown.js -->	
	<script src="<?php echo e(URL::asset('assets/js/jquery.knob.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('assets/js/jquery.throttle.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('assets/js/jquery.classycountdown.js')); ?>"></script>
        <script src="assets/js/utility.js"></script>
		<script>
    $(document).ready(function() {
        $('.bxslide').bxSlider({
        auto: true,
        mode: 'fade',
        autoControls: false,
        stopAutoOnClick:false,
        pager: false,
        slideWidth: 2000
    });
   $('#countdown1').ClassyCountdown({
    end: '1388268325',
    now: '1387999995',
    labels: true,
    style: {
        element: "",
        textResponsive: .5,
        days: {
                gauge: {
                        thickness: .10,
                        bgColor: "rgba(0,0,0,0)",
                        fgColor: "#1abc9c",
                        lineCap: 'round'
                },
                textCSS: 'font-weight:300; color:#fff;'
        },
        hours: {
                gauge: {
                        thickness: .10,
                        bgColor: "rgba(0,0,0,0)",
                        fgColor: "#05BEF6",
                        lineCap: 'round'
                },
                textCSS: ' font-weight:300; color:#fff;'
        },
        minutes: {
                gauge: {
                        thickness: .10,
                        bgColor: "rgba(0,0,0,0)",
                        fgColor: "#8e44ad",
                        lineCap: 'round'
                },
                textCSS: ' font-weight:300; color:#fff;'
        },
        seconds: {
                gauge: {
                        thickness: .10,
                        bgColor: "rgba(0,0,0,0)",
                        fgColor: "#f39c12",
                        lineCap: 'round'
                },
                textCSS: ' font-weight:300; color:#fff;'
        }

    },
    onEndCallback: function() {
        console.log("Time out!");
    }
    });
                                                        
    }); 
    
    
    

var modal = {
// Checks for a modal window and returns it, or
// else creates a new one and returns that
"initModal_nofade" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-window").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-window")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-window");
}
},

"initModal_result" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-result").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-result")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-result");
}
},

"initModal_add_profile" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-add-profile").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-add-profile")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-add-profile");
}
},

"initModal_fade" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-window-fade").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-window-fade")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-window");
}
},

"close_btn" : function(modal_var){
    $("<a>")
.attr("href", "#")
.addClass("modal-close-btn")
.html("&times;")
.click(function(event){
// Prevent the default action
event.preventDefault();
// Removes modal window
modal.boxout(event);
$("div").remove(".modal-overlay");
$("div").remove(".modal-overlay-result");
})
.appendTo(modal_var);
},

"close_result_btn" : function(modal_var){
    $("<a>")
.attr("href", "#")
.attr("data-toggle","modal")
.attr("data-target","#close-result-modal")
.addClass("modal-close-btn")
.html("&times;")
.appendTo(modal_var);
},

// Adds the window to the markup and fades it in
"boxin_fade" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
modal.boxout(event);
})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-window-fade,.modal-overlay")
.fadeIn(2000)
.fadeOut(5000);
},

// Adds the window to the markup and fades it in
"boxin_nofade" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
//modal.boxout(event);
modal.close_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-window,.modal-overlay")
.fadeIn(2000);

},

"boxin_add_profile" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
//modal.boxout(event);
modal.close_result_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element

modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-add-profile,.modal-overlay")
.fadeIn(1000);
},

"boxin_result" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay-result")
.click(function(event){
// Removes event
modal.close_result_btn(modal_var);
//modal.close_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-result,.modal-overlay-result")
.fadeIn(1000);

},

        
// Fades out the window and removes it from the DOM
"boxout" : function(event) {
// If an event was triggered by the element
// that called this function, prevents the
// default action from firing
if ( event!==undefined )
{
event.preventDefault();
}
// Removes the active class from all links
$("a").removeClass("active");
// Fades out the modal window, then removes
// it from the DOM entirely
$(".modal-window,.modal-add-profile, .modal-result")
.fadeOut("slow", function() {
$(this).remove();
}
);
}
};

//function to remove modal for close href in result modal
$(document).on('click','#close-result',function(e){
    modal.boxout(e);
$("div").remove(".modal-overlay");
$("div").remove(".modal-overlay-result");
});


function loginProcessor(form_id,login_btn,notification,url,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                var btn = $(login_btn);
                var info = $(notification);

                 $.ajaxSetup(
                        {
                                beforeSend: function()
                                {
                                        btn.attr("disabled",true);
                                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+"Authenticating... </span>");
                                },
                                complete: function()
                                {
                                        btn.attr("disabled",false);
                                        btn.html( "Login!");
                                }
                        });
                       
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(login_btn).html('Login');
                                      $(info).html("<div class=\"error\">"+res.text+"</div>");
                                }
                                if(res.type === "done"){
                                    $(info).html("<div class=\"success\">!!Success Please Wait.</div>");
                                     $(login_btn).html('Login');
                                     redirect(val);
                                     window.setTimeout(function(){
                                     window.location.href = res.text;     
                                     }, 3000);
                                }
                        });
                    });
                } 
                
     function formProcessorWithCallbacks(form_id,submit_btn,notification,return_text,url,callback_selector,mass_load_selector,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                var mass_loader = $(mass_load_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        info.html("<span style='color:#fff'>"+loader_gif.LARGE+" </span>");
                        //load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error\"> "+res.text+"</div>");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //load_body.html(res.content);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    return false;
                                    e.stopPropagation();
                                    //redirect(val);
                                }
                                
                                if(res.type === "done"){
                                    
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    mass_loader.html(res.mass_load);
                                    //loop(res);
                                   redirect(val);
                                   return false;
                                   e.stopImmediatePropagation();
                                }
                        });
                    });
                }
     function formProcessorNavWithCallbacks(form_id,url,callback_selector){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                //var btn = $(submit_btn);
                //var info = $(notification);
                var load_body = $(callback_selector);
                 
                        load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //btn.html(return_text);
                                     //btn.attr("disabled",false);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    //return false;
                                    event.stopPropagation();
                                    //redirect(val);
                                }
                                if(res.type === "done"){
                                   // info.html("<div class=\"success\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    //btn.attr("disabled",false);
                                    //btn.html(return_text);
                                    load_body.html(res.content);
                                    //redirect(val);
                                   //return false;
                                   event.stopImmediatePropagation();
                                }
                        });
                    });
                }   
     function formProcessorWithFileCallbacks(form_id,submit_btn,notification,return_text,url,callback_selector,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = new FormData(this);
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false,
                                contentType: false,
                                processData:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error text-center\">Error!! "+res.text+"</div>");
                                     //$(notification).delay(10000).fadeOut("fast");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    //redirect(val);
                                    return false;
                                    event.stopPropagation();
                                    
                                }
                                if(res.type === "done"){
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    redirect(val);
                                   //return false;
                                   event.stopImmediatePropagation();
                                }
                        });
                    });
                }           
    function redirect($var){
        if($var===true){
            document.location.href = document.location;
        }
        if($var==='logout'){
            document.location.href = 'home';
        }
        if($var==='checkout'){
            document.location.href = 'checkout';
        }
        if($var==='invoice'){
            document.location.href = 'invoice';
        }
        if($var===''){
            
        }
    } 
            
     function cartProcessor(form_id,button,url,cart_callback)
    {
        var btn_val = $(button).html(); 
        $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
                
            var request_method = $(this).attr("method"); //get form GET/POST method
            var form_data = new FormData(this); //Creates new FormData object

            $(button).html(loader_gif.SMALLER);
            $.ajax({ //ajax form submit
                    url :url,
                    type: request_method,
                    data : form_data,
                    dataType : "json",
                    contentType: false,
                    cache: false,
                    processData:false
            }).done(function(res){ //fetch server "json" messages when done
                    if(res.type === "error"){
                         modal.boxin_nofade('<div class="error">'+ res.text +"</div>",modal.initModal_nofade());
                         window.setTimeout(function(){
                         $(button).html(btn_val);
                          //$("div").remove(".modal-overlay");
                         }, 4000);
                         return false;
                    }
                    if(res.type === "done"){
                         $("div").remove(".modal-window-fade");
                        modal.boxin_fade('<div class="success">'+ res.text +"</div>",modal.initModal_fade());
                        $(cart_callback).html(res.content);
                         window.setTimeout(function(){
                         $(button).html(btn_val);
                         $("div").remove(".modal-overlay");
                         }, 4000);
                         return false;
                    }
            });
                
        });
    }  
     
   function formProcessor(form_id,submit_btn,notification,return_text,url,callback_selector,mass_load_selector,val){
     $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = new FormData(this);
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                var mass_loader = $(mass_load_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        info.html("<span style='color:#fff'>"+loader_gif.LARGE+" </span>");
                        //load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false,
                                contentType: false,
                                processData:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error\"> "+res.text+"</div>");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //load_body.html(res.content);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    return false;
                                    e.stopPropagation();
                                    //redirect(val);
                                }
                                
                                if(res.type === "done"){
                                    
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    mass_loader.html(res.mass_load);
                                    //loop(res);
                                    //redirect(val);
                                    e.stopImmediatePropagation();
                                   return false;
                                   
                                }
                        });
                    });
      
}
       
      
   function ajaxNav(click_id,offs,upd_body,url){
             $(document).on('click',click_id, function(e){
                e.preventDefault(); 
            var offset = $(this).find(offs).val();
           $.ajax({
              url:url,
              method:"POST",
              data:{action:click_id,offset:offset},
              dataType:"text",
              success:function(data){
                  $(upd_body).html(data);
              }
           });
        });    
  }
  
  function fetchSearchData(form_id,obj_cat,upd_body,url)
  {
      $(document).on('submit',form_id,function(e){
          e.preventDefault();
    var border_color = "#C2C2C2";
    var alpha_num = /^[a-zA-Z]{15}$/i;
    
	proceed = true;
	
	//simple input validation
	var search_box = $(this).find("#users-search");
        
            if(!$.trim(search_box.val())){ //if this field is empty 
                $(this).css('border-color','red'); //change border color to red   
                proceed = false; //set do not proceed flag
            }else{
		 $(this).css('border-color', border_color);
                 proceed = true;
            }
            
            if(proceed){
               var input_value = $(this).find('#users-search').val();
               input_value.replace(/\W/g, '');
               //alert(input_value);
               var action = $(this).find('#action').val();
               var search_by = $(this).find('#search-by').val();
               $(upd_body).html(loader_gif.LARGER);
               $('#users-search').attr('disabled',true);
               $('#search-submit-btn').attr('disabled',true);
                $.ajax({
              url:url,
              method:"POST",
              dataType:"text",
              data:{input_value:input_value,search_by:search_by,obj_cat:obj_cat,action:action},
               success:function(data){
              $(upd_body).html(data);
              $('#users-search').attr('disabled',false);
              $('#search-submit-btn').attr('disabled',false);
              }
        });
            }
      });
  
  
  }
  
  function fetch_selectsearch_obj(obj,input_id,search_by,obj_cat,upd_body,url)
         {
             $(document).on('input',input_id, function(){ 
           var input = $(input_id).val();
           
           $(upd_body).html('<option value="name">.....Loading....</option>');
           //alert(input);
           $.ajax({
              url: url,
              method:"POST",
              data:{search_obj:obj,input_value:input,search_by:search_by,obj_cat:obj_cat},
              dataType:"text",
              success:function(data){
                  $(upd_body).html(data); 
              }
           });
            
        });    
  }
  function showPopulateContainer(obj,obj_cat,url){
    $(document).on('input',obj,function(){
        
       var par = $(this).parent('#search-form');
       par.find('#search-submit-btn').removeAttr('disabled');
       par.find('#populate-container').css('display','block'); 
       //obj.replace(/\W/g,'');
       var search_by = par.find('#search-by').val();
        var upd_body = par.find('#populate-select');
      fetch_selectsearch_obj(obj,obj,search_by,obj_cat,upd_body,url);
    }).on('blur','#populate-select',function(){
        var par = $(this).parents('#search-form');
        //par.find('#search-submit-btn').attr('disabled','disabled');
        par.find('#populate-container').css('display','none');
    }).on('click','#populate-select',function(){
        var par = $(this).parents('#search-form');
        var split = $(this).val().split(" ");
        par.find(obj).val(split[0]) ;//search_box.val().replace(/\W/g,'');
    });
}



var loader_gif = {
     "SMALL" : "<div class=\"text-center\"> <img width=\"30px\" height=\"30px\" src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>",
    "SMALLER" : "<div class=\"text-center\"> <img width=\"20px\" height=\"20px\" src=\"assets/img/spinner.gif\"/>..processing</div>",
    "LARGE": "<div class=\"text-center\"> <img width=\"50px\" height=\"50px\" src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>",
    "LARGER": "<div class=\"text-center\"> <img src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>" 
    
};
  
		</script>
	<!-- //countdown.js -->
	<!-- menu js aim -->
	<script src="<?php echo e(URL::asset('assets/js/jquery.menu-aim.js')); ?>"> </script>
	<script src="<?php echo e(URL::asset('assets/js/main.js')); ?>"></script> <!-- Resource jQuery -->
        <script src="panel_assets/plugins/bxslider/js/jquery.bxslider.js"></script>
	<!-- //menu js aim --> 
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster --> 
</body>
</html>