<footer class="footer text-center"> 2017 &copy; Elite Admin brought to you by themedesigner.in </footer>
        </div>
        <!-- /#page-wrapper -->
       
        <div class="modal fade" style="" id="genericModal" tabindex="-1" role="dialog"
aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close"
data-dismiss="modal" aria-hidden="true">
&times;
</button>
<h4 class="modal-title text-center" id="myModalLabel">

</h4>
</div>
       <div id="staff_upd_results" class="text-center"></div>
       <div class="modal-body" id="generic-modal-body">
           
            </div>
        </div>
   </div>

</div>
</div><!-- /.modal-content -->
</div>
   
    <!-- /#wrapper -->
    <!-- jQuery -->
    
    <script src="panel_assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
    
    <!-- Bootstrap Core JavaScript --> 
    <script src="panel_assets/bootstrap/js/tether.min.js"></script>
     <script src="panel_assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="panel_assets/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    
    <!-- Menu Plugin JavaScript -->
    <script src="panel_assets/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="panel_assets/js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="panel_assets/js/waves.js"></script>
    <!--Counter js -->
    <script src="panel_assets/plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="panel_assets/plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!--Morris JavaScript -->
    <script src="panel_assets/plugins/bower_components/raphael/raphael-min.js"></script>
    <script src="panel_assets/plugins/bower_components/morrisjs/morris.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="panel_assets/js/custom.min.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="panel_assets/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="panel_assets/plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
    <script src="panel_assets/js/dashboard1.js"></script>
    <!-- Sparkline chart JavaScript -->
    
    <script src="panel_assets/plugins/select2/select2.min.js"></script>
    
    <script src="panel_assets/plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
    <script src="panel_assets/plugins/bower_components/bootstrap-switch/bootstrap-switch.min.js"></script>
     <script src="panel_assets/plugins/bower_components/dropify/dist/js/dropify.min.js"></script>
      <script src="panel_assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
      <script src="panel_assets/plugins/bower_components/sweetalert/sweetalert.min.js"></script>
      <script src="panel_assets/plugins/bower_components/sweetalert/jquery.sweet-alert.custom.js"></script>
       <script src="panel_assets/plugins/bxslider/js/jquery.bxslider.js"></script>
      <script src="panel_assets/js/widget.js"></script>
      <script src="assets/js/bootstrap.js"></script>
    
    <script>
         
        $(document).ready(function() {
    $('.select2').select2();
    
    $('.bxslider').bxSlider({
        auto: true,
      autoControls: true,
      stopAutoOnClick: true,
      pager: true,
      mode: 'fade',
    captions: true,
     slideWidth: 1680
    });
    $('.bxslide').bxSlider({
        auto: true,
        mode: 'fade',
        autoControls: false,
        stopAutoOnClick:false,
        pager: false,
        slideWidth: 2000
    });

      $(".textarea").wysihtml5({
          toolbar: {
    "font-styles": false, //Font styling, e.g. h1, h2, etc. Default true
    "emphasis": false, //Italics, bold, etc. Default true
    "lists": true, //(Un)ordered lists, e.g. Bullets, Numbers. Default true
    "html": false, //Button which allows you to edit the generated HTML. Default false
    "link": false, //Button to insert a link. Default true
    "image": false, //Button to insert an image. Default true,
    "color": false, //Button to change color of font  
    "blockquote": false, //Blockquote 
    "fa":true
    //"size": <buttonsize> //default: none, other options are xs, sm, lg
  }
      });
        $('.dropify').dropify();

        // Translated
        $('.dropify-fr').dropify({
            messages: {
                default: 'Glissez-déposez un fichier ici ou cliquez',
                replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                remove: 'Supprimer',
                error: 'Désolé, le fichier trop volumineux'
            }
        });

        // Used events
        var drEvent = $('#input-file-events').dropify();

        drEvent.on('dropify.beforeClear', function(event, element) {
            return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
        });

        drEvent.on('dropify.afterClear', function(event, element) {
            alert('File deleted');
        });

        drEvent.on('dropify.errors', function(event, element) {
            console.log('Has Errors');
        });

        var drDestroy = $('#input-file-to-destroy').dropify();
        drDestroy = drDestroy.data('dropify')
        $('#toggleDropify').on('click', function(e) {
            e.preventDefault();
            if (drDestroy.isDropified()) {
                drDestroy.destroy();
            } else {
                drDestroy.init();
            }
        })
    });
    
    
    

var modal = {
// Checks for a modal window and returns it, or
// else creates a new one and returns that
"initModal_nofade" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-window").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-window")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-window");
}
},

"initModal_result" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-result").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-result")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-result");
}
},

"initModal_add_profile" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-add-profile").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-add-profile")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-add-profile");
}
},

"initModal_fade" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-window-fade").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-window-fade")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-window");
}
},

"close_btn" : function(modal_var){
    $("<a>")
.attr("href", "#")
.addClass("modal-close-btn")
.html("&times;")
.click(function(event){
// Prevent the default action
event.preventDefault();
// Removes modal window
modal.boxout(event);
$("div").remove(".modal-overlay");
$("div").remove(".modal-overlay-result");
})
.appendTo(modal_var);
},

"close_result_btn" : function(modal_var){
    $("<a>")
.attr("href", "#")
.attr("data-toggle","modal")
.attr("data-target","#close-result-modal")
.addClass("modal-close-btn")
.html("&times;")
.appendTo(modal_var);
},

// Adds the window to the markup and fades it in
"boxin_fade" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
modal.boxout(event);
})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-window-fade,.modal-overlay")
.fadeIn(2000)
.fadeOut(5000);
},

// Adds the window to the markup and fades it in
"boxin_nofade" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
//modal.boxout(event);
modal.close_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-window,.modal-overlay")
.fadeIn(2000);

},

"boxin_add_profile" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
//modal.boxout(event);
modal.close_result_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element

modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-add-profile,.modal-overlay")
.fadeIn(1000);
},

"boxin_result" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay-result")
.click(function(event){
// Removes event
modal.close_result_btn(modal_var);
//modal.close_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-result,.modal-overlay-result")
.fadeIn(1000);

},

        
// Fades out the window and removes it from the DOM
"boxout" : function(event) {
// If an event was triggered by the element
// that called this function, prevents the
// default action from firing
if ( event!==undefined )
{
event.preventDefault();
}
// Removes the active class from all links
$("a").removeClass("active");
// Fades out the modal window, then removes
// it from the DOM entirely
$(".modal-window,.modal-add-profile, .modal-result")
.fadeOut("slow", function() {
$(this).remove();
}
);
}
};

//function to remove modal for close href in result modal
$(document).on('click','#close-result',function(e){
    modal.boxout(e);
$("div").remove(".modal-overlay");
$("div").remove(".modal-overlay-result");
});


function loginProcessor(form_id,login_btn,notification,url){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                var btn = $(login_btn);
                var info = $(notification);

                 $.ajaxSetup(
                        {
                                beforeSend: function()
                                {
                                        btn.attr("disabled",true);
                                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+"Authenticating... </span>");
                                },
                                complete: function()
                                {
                                        btn.attr("disabled",false);
                                        btn.html( "Login!");
                                }
                        });
                       
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(login_btn).html('Login');
                                      $(info).html("<div class=\"error\">"+res.text+"</div>");
                                }
                                if(res.type === "done"){
                                    $(info).html("<div class=\"success\">!!Success Please Wait.</div>");
                                     $(login_btn).html('Login');
                                     window.setTimeout(function(){
                                     window.location.href = res.text;     
                                     }, 3000);
                                }
                        });
                    });
                } 
                
     function formProcessorWithCallbacks(form_id,submit_btn,notification,return_text,url,callback_selector,mass_load_selector,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                var mass_loader = $(mass_load_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        //load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //load_body.html(res.content);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    return false;
                                    event.stopPropagation();
                                    //redirect(val);
                                }
                                if(res.type === "done"){
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    mass_loader.html(res.mass_load);
                                    //loop(res);
                                    //redirect(val);
                                   return false;
                                   event.stopImmediatePropagation();
                                }
                        });
                    });
                }
     function formProcessorNavWithCallbacks(form_id,url,callback_selector){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                //var btn = $(submit_btn);
                //var info = $(notification);
                var load_body = $(callback_selector);
                 
                        load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //btn.html(return_text);
                                     //btn.attr("disabled",false);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    //return false;
                                    event.stopPropagation();
                                    //redirect(val);
                                }
                                if(res.type === "done"){
                                   // info.html("<div class=\"success\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    //btn.attr("disabled",false);
                                    //btn.html(return_text);
                                    load_body.html(res.content);
                                    //redirect(val);
                                   //return false;
                                   event.stopImmediatePropagation();
                                }
                        });
                    });
                }   
     function formProcessorWithFileCallbacks(form_id,submit_btn,notification,return_text,url,callback_selector,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = new FormData(this);
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false,
                                contentType: false,
                                processData:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error text-center\">Error!! "+res.text+"</div>");
                                     //$(notification).delay(10000).fadeOut("fast");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    //redirect(val);
                                    return false;
                                    event.stopPropagation();
                                    
                                }
                                if(res.type === "done"){
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    redirect(val);
                                   //return false;
                                   event.stopImmediatePropagation();
                                }
                        });
                    });
                }           
    function redirect($var){
        if($var===true){
            document.location.href = document.location;
        }
    } 
            
     function cartProcessor(button,url,cart_callback)
    {
        var btn_val = $(button).html(); 
        $(button).submit(function(e){
            e.preventDefault(); //prevent default action 
                
            var request_method = $(this).attr("method"); //get form GET/POST method
            var form_data = new FormData(this); //Creates new FormData object

            $(button).html(loader_gif.SMALLER);
            $.ajax({ //ajax form submit
                    url :url,
                    type: request_method,
                    data : form_data,
                    dataType : "json",
                    contentType: false,
                    cache: false,
                    processData:false
            }).done(function(res){ //fetch server "json" messages when done
                    if(res.type === "error"){
                         modal.boxin_fade('<div class="error">'+ res.text +"</div>",modal.initModal_fade());
                         window.setTimeout(function(){
                         $(button).html(btn_val);
                          $("div").remove(".modal-overlay");
                         }, 6000);
                    }
                    if(res.type === "done"){
                         $("div").remove(".modal-window-fade");
                        modal.boxin_fade('<div class="success">'+ res.content +"</div>",modal.initModal_fade());
                         window.setTimeout(function(){
                         $(button).html(btn_val);
                         }, 4000);
                    }
            });
                
        });
    }  
      
      
    
                
   function formProcessor(form_id,submit_btn,notification,return_text,url,callback_selector){
      $(form_id).submit(function(e){
        e.preventDefault();
        var data = $(this).serialize();
        
        var btn = $(submit_btn);
        var info = $(notification);
        
        var border_color = "#C2C2C2";
	proceed = true;
        
        $($(this).find("input[data-required=true], textarea[data-required=true], select[data-required=true]")).each(function(){
            if(!$.trim($(this).val())){ //if this field is empty 
                $(this).css('border-color','red'); //change border color to red   
                proceed = false; //set do not proceed flag
            }
            //check invalid email
            var email_reg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/; 
            var name_reg = /^[a-zA-Z]{15}$/i;
            var address_reg = /^([a-zA-Z ,_\-\'\.\"0-9]){4,50}$/;
            
            
       
            if($(this).attr("type")==="email" && !email_reg.test($.trim($(this).val()))){
                $(this).css('border-color','red'); //change border color to red   
                proceed = false; //set do not proceed flag              
            }  
            
             if($(this).attr("class")==="txt" && !name_reg.test($.trim($(this).val()))){
            $(this).css('border-color','red');
            //$(this).append("<div>this field should contain alphabets only</div>");//change border color to red   
                proceed = false; //set do not proceed flag     
         }
         
         if( $(this).attr("class")==="addres" && !address_reg.test($.trim($(this).val()))){
            $(this).css('border-color','red'); //change border color to red
            //$(this).append("<div>this field should contain alphanumeric keys only</div>");
                proceed = false; //set do not proceed flag     
         }
            
	}).on("input", function(){ //change border color to original
		 $(this).css('border-color', border_color);
	});
        
        if(proceed){
       var form_data = new FormData(this);
        $.ajaxSetup(
        {
                beforeSend: function()
                {
                        btn.attr("disabled",true);
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                },
                complete: function()
                {
                        btn.attr("disabled",false);
                        btn.html( return_text);
                }
        });
  
        $.ajax(
        {
                type: "POST",
                data: form_data,
                url: url,
                cache:false,
                contentType: false,
                processData:false,
                success: function(msg)
                {
                        info.fadeIn("fast");
                        info.html(msg).delay(10000).fadeOut("fast");
                        btn.attr("disabled",false);
                        btn.html(return_text);
                       //AjaxLoadObject(callback_action,callback_selector,url);
                }
        });
        }
});
      
}
       
      
   function ajaxNav(click_id,offs,upd_body,url){
             $(document).on('click',click_id, function(e){
                e.preventDefault(); 
            var offset = $(this).find(offs).val();
           $.ajax({
              url:url,
              method:"POST",
              data:{action:click_id,offset:offset},
              dataType:"text",
              success:function(data){
                  $(upd_body).html(data);
              }
           });
        });    
  }
  
  function fetchSearchData(form_id,obj_cat,upd_body,url)
  {
      $(document).on('submit',form_id,function(e){
          e.preventDefault();
    var border_color = "#C2C2C2";
    var alpha_num = /^[a-zA-Z]{15}$/i;
    
	proceed = true;
	
	//simple input validation
	var search_box = $(this).find("#users-search");
        
            if(!$.trim(search_box.val())){ //if this field is empty 
                $(this).css('border-color','red'); //change border color to red   
                proceed = false; //set do not proceed flag
            }else{
		 $(this).css('border-color', border_color);
                 proceed = true;
            }
            
            if(proceed){
               var input_value = $(this).find('#users-search').val();
               input_value.replace(/\W/g, '');
               //alert(input_value);
               var action = $(this).find('#action').val();
               var search_by = $(this).find('#search-by').val();
               $(upd_body).html(loader_gif.LARGER);
               $('#users-search').attr('disabled',true);
               $('#search-submit-btn').attr('disabled',true);
                $.ajax({
              url:url,
              method:"POST",
              dataType:"text",
              data:{input_value:input_value,search_by:search_by,obj_cat:obj_cat,action:action},
               success:function(data){
              $(upd_body).html(data);
              $('#users-search').attr('disabled',false);
              $('#search-submit-btn').attr('disabled',false);
              }
        });
            }
      });
  
  
  }
  
  function fetch_selectsearch_obj(obj,input_id,search_by,obj_cat,upd_body,url)
         {
             $(document).on('input',input_id, function(){ 
           var input = $(input_id).val();
           
           $(upd_body).html('<option value="name">.....Loading....</option>');
           //alert(input);
           $.ajax({
              url: url,
              method:"POST",
              data:{search_obj:obj,input_value:input,search_by:search_by,obj_cat:obj_cat},
              dataType:"text",
              success:function(data){
                  $(upd_body).html(data); 
              }
           });
            
        });    
  }
  function showPopulateContainer(obj,obj_cat,url){
    $(document).on('input',obj,function(){
        
       var par = $(this).parent('#search-form');
       par.find('#search-submit-btn').removeAttr('disabled');
       par.find('#populate-container').css('display','block'); 
       //obj.replace(/\W/g,'');
       var search_by = par.find('#search-by').val();
        var upd_body = par.find('#populate-select');
      fetch_selectsearch_obj(obj,obj,search_by,obj_cat,upd_body,url);
    }).on('blur','#populate-select',function(){
        var par = $(this).parents('#search-form');
        //par.find('#search-submit-btn').attr('disabled','disabled');
        par.find('#populate-container').css('display','none');
    }).on('click','#populate-select',function(){
        var par = $(this).parents('#search-form');
        var split = $(this).val().split(" ");
        par.find(obj).val(split[0]) ;//search_box.val().replace(/\W/g,'');
    });
}



var loader_gif = {
     "SMALL" : "<div class=\"text-center\"> <img width=\"30px\" height=\"30px\" src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>",
    "SMALLER" : "<div class=\"text-center\"> <img width=\"20px\" height=\"20px\" src=\"assets/img/spinner.gif\"/>..processing</div>",
    "LARGE": "<div class=\"text-center\"> <img width=\"50px\" height=\"50px\" src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>",
    "LARGER": "<div class=\"text-center\"> <img src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>" 
    
};
   
     

     $(document).ready(function() {
           //formProcessorWithCallbacks('.manage-product-form','.manage-product-btn','.manage-product-msg',
   //'<span class="fa fa-tasks"><i class="tooltip-content3">Click to update or delete.</i></span>',
   //'manage-product','#load-upd-product')
     });
    </script>
    
</body>


<!-- Mirrored from eliteadmin.themedesigner.in/demos/eliteadmin-ecommerce/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 Oct 2017 16:52:02 GMT -->
</html>