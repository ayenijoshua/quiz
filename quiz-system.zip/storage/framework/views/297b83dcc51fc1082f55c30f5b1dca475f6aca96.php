<!--   USER PANEL PAGE              -->


<?php $__env->startSection('title'); ?>
Checkout
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    #genericModal,.cart{
        display: none;
    }
</style>

<div class="products">	 
    
    <div class="container" id="cart-container">
        <div style="display:<?=isset($_SESSION['chk_disp'])? 'none' :''?>">
        <button class="pull-left btn btn-rounded btn-success">Total Price:<?=isset($_SESSION['cart'])?$_SESSION['cart']->totalPrice:''?></button>
        <form class="checkout-form" method="post" action="manage-user">
           <?php echo e(csrf_field()); ?>

           <input type="hidden" name="action" value="get-checkout-form"> 
           <button id="" onclick="formProcessorWithCallbacks('.checkout-form','.checkout-btn','.generic-modal-body','Proceed to checkout','manage-user','.generic-modal-body','','')" 
                   type="submit" class="checkout-btn pull-right btn btn-rounded btn-success">Proceed to Checkout</button>
        </form>
        </div>
        
        <hr>
        <div class="generic-modal-body">
            <?=$get_cart_items?>
        </div>
           
	</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>