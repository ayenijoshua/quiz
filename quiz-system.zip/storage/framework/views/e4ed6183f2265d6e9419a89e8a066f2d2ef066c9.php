
<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<!DOCTYPE html>
 <html lang="en">
 
<!-- Mirrored from demo.smartaddons.com/templates/html/market/quickview.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Nov 2017 16:28:20 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
     <!-- Basic page needs
	============================================ -->
	 <title>Market - Premium Multipurpose HTML5/CSS3 Theme</title>
	 <meta charset="utf-8" />
     <meta name="keywords" content="boostrap, responsive, html5, css3, jquery, theme, multicolor, parallax, retina, business" />
     <meta name="author" content="Magentech" />
     <meta name="robots" content="index, follow" />
   
	 <!-- Mobile specific metas
	============================================ -->
	 <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	
	 <!-- Favicon
	============================================ -->
     <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png" />
     <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png" />
     <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png" />
     <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png" />
     <link rel="shortcut icon" href="ico/favicon.png" />
	
	 <!-- Google web fonts
	============================================ -->
     <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
     <!-- Libs CSS
	============================================ -->
     <link rel="stylesheet" href="assets/css/bootstrap/css/bootstrap.min.css" />
	 <link href="assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	 <link href="assets/js/datetimepicker/bootstrap-datetimepicker.min.css" rel="stylesheet" />
     <link href="assets/js/owl-carousel/owl.carousel.css" rel="stylesheet" />
	 <link href="assets/css/themecss/lib.css" rel="stylesheet" />
	 <link href="assets/js/jquery-ui/jquery-ui.min.css" rel="stylesheet" />
	
	 <!-- Theme CSS
	============================================ -->
   	 <link href="assets/css/themecss/so_megamenu.css" rel="stylesheet" />
     <link href="assets/css/themecss/so-categories.css" rel="stylesheet" />
	 <link href="assets/css/themecss/so-listing-tabs.css" rel="stylesheet" />
	 <link href="assets/css/footer1.css" rel="stylesheet">
	 <link href="assets/css/header1.css" rel="stylesheet">
	 <link id="color_scheme" href="assets/css/theme.css" rel="stylesheet" />
	 <link href="assets/css/responsive.css" rel="stylesheet" />
         <script type="text/javascript" src="assets/js/jquery-2.2.4.min.js"></script>
	
         
         <style>
             .view-cart-btn{
   
border: none;
-webkit-border-radius: 50%;
-moz-border-radius: 50%;
-o-border-radius: 50%;
-ms-border-radius: 50%;
border-radius: 50%;
font-size: 50px;
outline: none;
} 
.modal-window,.modal-window-fade{   
width: 300px;
top: 50%;
left:50%;
position:fixed;
z-index:99999999;
}
.modal-overlay{
   z-index:999999999; 
}
.cart-img{
    
}
        </style>
        
   <script>       
 $(document).ready(function(){
 cartProcessor('.add-to-cart-form','','manage-cart','.cart-callback');
        formProcessorWithCallbacks('#view-cart-form','.view-cart-bt','#generic-modal-body',
        '',
        'manage-cart','.cart-callback');
 });
   </script>
	

 </head>

 <body class="res layout-subpage">
     <div id="wrapper" class="wrapper-full ">
	<!-- Main Container  -->
	 <div class="main-container container">
		
		 <div class="row">
			 <!--Middle Part Start-->
			 <div id="content" class="col-md-12 col-sm-12">
				
				 <div class="product-view row">
					 <div class="left-content-product col-lg-12 col-xs-12">
						 <div class="row">
							 <div class="content-product-left  col-sm-6 col-xs-12 ">
							<div class="large-image  ">
             <img itemprop="image" class="product-image-zoom" src="products_img/<?=$product->product_fv_path?>" data-zoom-image="products_img/<?=$product->product_fv_path?>" title="<?=$product->product_name?>" alt="<?=$product->product_name?>" />
     </div>

     <div id="thumb-slider" class="owl-theme owl-loaded owl-drag full_slider">
             <a data-index="0" class="img thumbnail " data-image="products_img/<?=$product->product_fv_path?>" title="<?=$product->product_name?>">
                     <img src="products_img/<?=$product->product_fv_path?>" title="<?=$product->product_name?>" alt="<?=$product->product_name?>" />
             </a>
             <a data-index="1" class="img thumbnail" data-image="products_img/<?=$product->product_bv_path?>" title="<?=$product->product_name?>">
                     <img src="products_img/<?=$product->product_bv_path?>" title="<?=$product->product_name?>" alt="<?=$product->product_name?>" />
             </a>
             <a data-index="2" class="img thumbnail" data-image="products_img/<?=$product->product_sv_path?>" title="<?=$product->product_name?>">
                     <img src="products_img/<?=$product->product_sv_path?>" title="<?=$product->product_name?>" alt="<?=$product->product_name?>" />
             </a>
             
     </div>	 
								 
							 </div>

							 <div class="content-product-right col-sm-6 col-xs-12">
								 <div class="title-product">
									 <h1><?=$product->product_name?></h1>
								 </div>
								 <!-- Review ---->
								 <div class="box-review form-group">
									 <div class="ratings">
										 <div class="rating-box">
											 <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
											 <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
											 <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
											 <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
											 <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
										 </div>
									 </div>
									 <a class="reviews_button" href="quickview.php.html" onclick="$('a[href=\'#tab-review\']').trigger('click'); return false;">0 reviews </a>	
								 </div>

								 <div class="product-label form-group">
									 <div class="product_page_price price" itemprop="offerDetails" itemscope="" itemtype="">
										 <span class="price-new" itemprop="price"><?=$product->product_price?></span>
										 <span class="price-old">$122.00 </span>
									 </div>
									 <div class="stock"><span>Availability: </span>  <span class="status-stock">In Stock </span></div>
								 </div>

								 <div class="product-box-desc">
									 <div class="inner-box-desc">
										 <div class="price-tax"> <?=$check_size?> </div>
										 <div class="reward"><span>QTY - </span> <?=$qty?> </div>
										 <div class="brand"><span>Brand: </span><a href="#"><?=$product_controller->selectObject('brand_name','brands','brand_id',$product->brand_id)?></a>		 </div>
										 <div class="model"><span>Product Code: </span> <?=$product->product_sku?> </div>
									 </div>
								 </div>


								 <div id="product">
									 
									 <div class="image_option_type form-group required">
                                                                             <h4>Product Highlights</h4>
										<?=$product_controller->convertToList($product->product_highlights)?>
									 </div>
									
									 <div class="box-checkbox form-group required">
                                                                             <h4>Product Description</h4>
										 <?=$product->product_desc?>
									 </div>

									 <div class="form-group box-info-product">
                                                                             <div id="cart-info" class="modal-window bg-success"></div>
                                                                              <form class="add-to-cart-form" action="manage-cart" method="post">
										 <div class="option quantity">
                                                                                   
										 </div>
										 <div class="cart">
                                                                         
                                                                        <input type="hidden" name="product_id" value="<?=$product->product_id?>" />
                                                                        <?php echo e(csrf_field()); ?>

                                                                        <input type="hidden" name="product_price" value="<?=$product->product_price?>" />
                                                                        <input type="hidden" name="product_name" value="<?=$product->product_name?>" />
                                                                        <input type="hidden" name="product_img" value="<?=$product->product_fv_path?>" />
                                                                        <input type="hidden" name="product_qty" value="<?=$product->product_qty?>" />
                                                                        <input type="hidden" name="product_size" value="<?=$product->size_id?>" />
                                                                        <input type="hidden" name="action" value="add" />
									<input type="submit" data-toggle="tooltip" title="" value="Add to Cart" data-toggle="tooltip" 
                                                                               title="Add to Cart" id="" class="btn btn-mega btn-lg add-to-cart-btn" onclick="cartProcessor('.add-to-cart-form','','manage-cart','.cart-callback');" />
                                                                        	 
                                                                                 </div>
										 <div class="add-to-links wish_comp">
											 <ul class="blank list-inline">
												 
												 
											 </ul>
										 </div>
                                                                                    </form>
									 </div>
                                                                      

								 </div>
								 <!-- end box info product -->

							 </div>
						 </div>
					 </div>
					
				
				 </div>
                             
                              
 <script>
     
    var modal = {
// Checks for a modal window and returns it, or
// else creates a new one and returns that
"initModal_nofade" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-window").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-window")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-window");
}
},

"initModal_result" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-result").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-result")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-result");
}
},

"initModal_add_profile" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-add-profile").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-add-profile")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-add-profile");
}
},

"initModal_fade" : function() {
// If no elements are matched, the length
// property will return 0
if ( $(".modal-window-fade").length===0 )
{
// Creates a div, adds a class, and
// appends it to the body tag
return $("<div>")
.addClass("modal-window-fade")
.appendTo("body");
}
else
{
// Returns the modal window if one
// already exists in the DOM
return $(".modal-window");
}
},

"close_btn" : function(modal_var){
    $("<a>")
.attr("href", "#")
.addClass("modal-close-btn")
.html("&times;")
.click(function(event){
// Prevent the default action
event.preventDefault();
// Removes modal window
modal.boxout(event);
$("div").remove(".modal-overlay");
$("div").remove(".modal-overlay-result");
})
.appendTo(modal_var);
},

"close_result_btn" : function(modal_var){
    $("<a>")
.attr("href", "#")
.attr("data-toggle","modal")
.attr("data-target","#close-result-modal")
.addClass("modal-close-btn")
.html("&times;")
.appendTo(modal_var);
},

// Adds the window to the markup and fades it in
"boxin_fade" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
modal.boxout(event);
})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-window-fade,.modal-overlay")
.fadeIn(2000)
.fadeOut(5000);
},

// Adds the window to the markup and fades it in
"boxin_nofade" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
//modal.boxout(event);
modal.close_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-window,.modal-overlay")
.fadeIn(2000);

},

"boxin_add_profile" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay")
.click(function(event){
// Removes event
//modal.boxout(event);
modal.close_result_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element

modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-add-profile,.modal-overlay")
.fadeIn(1000);
},

"boxin_result" : function(data, modal_var) {
// Creates an overlay for the site, adds
// a class and a click event handler, then
// appends it to the body element
$("<div>")
.hide()
.addClass("modal-overlay-result")
.click(function(event){
// Removes event
modal.close_result_btn(modal_var);
//modal.close_btn(modal_var);

})
.appendTo("body");
// Loads data into the modal window and
// appends it to the body element
modal_var
.hide()
.html(data)
.appendTo("body");
// Fades in the modal window and overlay
$(".modal-result,.modal-overlay-result")
.fadeIn(1000);

},

        
// Fades out the window and removes it from the DOM
"boxout" : function(event) {
// If an event was triggered by the element
// that called this function, prevents the
// default action from firing
if ( event!==undefined )
{
event.preventDefault();
}
// Removes the active class from all links
$("a").removeClass("active");
// Fades out the modal window, then removes
// it from the DOM entirely
$(".modal-window,.modal-add-profile, .modal-result")
.fadeOut("slow", function() {
$(this).remove();
}
);
}
};

//function to remove modal for close href in result modal
$(document).on('click','#close-result',function(e){
    modal.boxout(e);
$("div").remove(".modal-overlay");
$("div").remove(".modal-overlay-result");
}); 
     
     function cartProcessor(form_id,button,url,cart_callback)
    {
        var btn_val = $(button).html(); 
        $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
                
            var request_method = $(this).attr("method"); //get form GET/POST method
            var form_data = new FormData(this); //Creates new FormData object

            $(button).html(loader_gif.SMALLER);
            $.ajax({ //ajax form submit
                    url :url,
                    type: request_method,
                    data : form_data,
                    dataType : "json",
                    contentType: false,
                    cache: false,
                    processData:false
            }).done(function(res){ //fetch server "json" messages when done
                    if(res.type === "error"){
                        $('#cart-info').html('<div class="error" style="padding:5px;">'+ res.text +"</div>");
                         //modal.boxin_nofade('<div class="error">'+ res.text +"</div>",modal.initModal_nofade());
                         window.setTimeout(function(){
                         $(button).html(btn_val);
                         $('#cart-info').html('<div class="error"></div>');
                         }, 5000);
                         return false;
                    }
                    if(res.type === "done"){
                         //$("div").remove(".modal-window-fade");
                        //modal.boxin_fade('<div class="success">'+ res.text +"</div>",modal.initModal_fade());
                        $('#cart-info').html('<div class="error" style="padding:5px;">'+ res.text +"</div>");
                        $(cart_callback).html(res.content);
                         window.setTimeout(function(){
                         $(button).html(btn_val);
                          $('#cart-info').html('<div class="error"></div>');
                         }, 50000);
                         return false;
                    }
            });
                
        });
    }  
    function formProcessorWithCallbacks(form_id,submit_btn,notification,return_text,url,callback_selector,mass_load_selector,val){
  $(form_id).submit(function(e){
            e.preventDefault(); //prevent default action 
               var data = $(this).serialize();
                var btn = $(submit_btn);
                var info = $(notification);
                var load_body = $(callback_selector);
                var mass_loader = $(mass_load_selector);
                 
                        btn.html("<span style='color:#fff'>"+loader_gif.SMALLER+" </span>");
                        info.html("<span style='color:#fff'>"+loader_gif.LARGE+" </span>");
                        //load_body.html("<span style='color:#fff'>"+loader_gif.SMALL+" </span>");
                        $.ajax({ //ajax form submit
                                type: "POST",
                                data: data,
                                url:url,
                                dataType:"json",
                                cache:false
                        }).done(function(res){ //fetch server "json" messages when done
                                if(res.type === "error"){
                                     $(notification).html("<div class=\"error text-center\"> "+res.text+"</div>");
                                     btn.html(return_text);
                                     btn.attr("disabled",false);
                                     //load_body.html(res.content);
                                     //$(notification).html("<div class=\"error\">Error!! "+res.text+"</div>");
                                     //info.delay(10000).fadeOut("fast");
                                    //info.html(res.text).delay(10000).fadeOut("fast");
                                    return false;
                                    e.stopPropagation();
                                    //redirect(val);
                                }
                                
                                if(res.type === "done"){
                                    
                                    info.html("<div class=\"success text-center\">"+res.text+"</div>");
                                    //info.html("<div class=\"success\">"+res.text+"</div>").delay(10000).fadeOut("fast");
                                    btn.attr("disabled",false);
                                    btn.html(return_text);
                                    load_body.html(res.content);
                                    mass_loader.html(res.mass_load);
                                    //loop(res);
                                   redirect(val);
                                   return false;
                                   e.stopImmediatePropagation();
                                }
                        });
                    });
                }
    
    var loader_gif = {
     "SMALL" : "<div class=\"text-center\"> <img width=\"30px\" height=\"30px\" src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>",
    "SMALLER" : "<div class=\"text-center\"> <img width=\"20px\" height=\"20px\" src=\"assets/img/spinner.gif\"/>..processing</div>",
    "LARGE": "<div class=\"text-center\"> <img width=\"50px\" height=\"50px\" src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>",
    "LARGER": "<div class=\"text-center\"> <img src=\"assets/img/spinner.gif\"/>\n\
..fetching data</div>" 
    
};
 </script>
				
				 <script type="text/javascript">
					// Cart add remove functions
					var cart = {
						'add': function(product_id, quantity) {
							parent.addProductNotice('Product added to Cart', '<img src="assets/image/demo/shop/product/e11.jpg" alt="">', '<h3><a href="#">Apple Cinema 30"</a> added to <a href="#">shopping cart</a>!</h3>', 'success');
						}
					}

					var wishlist = {
						'add': function(product_id) {
							parent.addProductNotice('Product added to Wishlist', '<img src="assets/image/demo/shop/product/e11.jpg" alt="">', '<h3>You must <a href="#">login</a>  to save <a href="#">Apple Cinema 30"</a> to your <a href="#">wish list</a>!</h3>', 'success');
						}
					}
					var compare = {
						'add': function(product_id) {
							parent.addProductNotice('Product added to compare', '<img src="assets/image/demo/shop/product/e11.jpg" alt="">', '<h3>Success: You have added <a href="#">Apple Cinema 30"</a> to your <a href="#">product comparison</a>!</h3>', 'success');
						}
					}

					
				</script>

				
			 </div>
			
			
		 </div>
		 <!--Middle Part End-->
	 </div>
	 <!-- //Main Container -->
	
 <style type="text/css">
	#wrapper{box-shadow:none;}
	#wrapper > *:not(.main-container){display: none;}
	#content{margin:0}
	.container{width:100%;}
	
	.product-info .product-view,.left-content-product,.box-info-product{margin:0;}
	.left-content-product .content-product-right .box-info-product .cart input{padding:12px 16px;}

	.left-content-product .content-product-right .box-info-product .add-to-links{ width: auto;  float: none; margin-top: 0px; clear:none; }
	.add-to-links ul li{margin:0;}
	
</style></div>

 <!-- Include Libs & Plugins
	============================================ -->
 <!-- Placed at the end of the document so the pages load faster -->
 <script type="text/javascript" src="assets/js/jquery-2.2.4.min.js"></script>
 <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
 <script type="text/javascript" src="assets/js/owl-carousel/owl.carousel.js"></script>
 <script type="text/javascript" src="assets/js/themejs/libs.js"></script>
 <script type="text/javascript" src="assets/js/unveil/jquery.unveil.js"></script>
 <script type="text/javascript" src="assets/js/countdown/jquery.countdown.min.js"></script>
 <script type="text/javascript" src="assets/js/dcjqaccordion/jquery.dcjqaccordion.2.8.min.js"></script>
 <script type="text/javascript" src="assets/js/datetimepicker/moment.js"></script>
 <script type="text/javascript" src="assets/js/datetimepicker/bootstrap-datetimepicker.min.js"></script>
 <script type="text/javascript" src="assets/js/jquery-ui/jquery-ui.min.js"></script>
 

 <!-- Theme files
============================================ -->

 
 <script type="text/javascript" src="assets/js/themejs/so_megamenu.js"></script>
 <script type="text/javascript" src="assets/js/themejs/addtocart.js"></script>
 <script type="text/javascript" src="assets/js/themejs/application.js"></script>

</body>

</html>