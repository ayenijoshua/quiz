<!-- ADMIN VIEW ORDERS PAGE       -->




<?php $__env->startSection('title'); ?>
Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('orders-active'); ?>
active text-danger
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>;
<script>
     $(document).ready(function() {
     
     }); 
</script>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
<div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 ">
                        <h4 class="page-title">Orders</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12 ">
                        <ol class="breadcrumb">
                            <li><a href="#">Order History</a></li>
                            <li class="active">Manage Orders</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
    
    
    
    <ul id="myTab" class="nav customtab nav-tabs">
<li class="nav-item active">
<a href="#all"  data-toggle="tab">
    All Orders <span class="badge"><?=$count_all?></span>
</a>
</li>

<li class="nav-item">
<a href="#pending"  data-toggle="tab">
Pending Orders <span class="badge"><?=$count_pending?></span>
</a>
</li>

<li class="nav-item">
<a href="#approved"  data-toggle="tab">
Approved orders <span class="badge"><?=$count_approved?></span>
</a>
</li>

<li class="nav-item">
<a href="#canceled"  data-toggle="tab">
Canceled Orders <span class="badge"><?=$count_canceled?></span>
</a>
</li>

</ul>
    
    <div id="myTabContent" class="tab-content">
        <div class="tab-pane fade in active" id="all" aria-expanded="true">
            <?=$all_orders?>
        </div>
        
        <div class="tab-pane fade" id="pending" >
            <?=$pending_orders?>
        </div>
        
        <div class="tab-pane fade" id="approved" >
            <?=$approved_orders?> 
        </div>
        
        <div class="tab-pane fade" id="canceled">
          <?=$canceled_orders?>  
        </div>
                
                
    </div>
 </div>

</div>
            <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>