<!DOCTYPE html>
<html lang="en">
<head>
<title>Invoice</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Smart Bazaar Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

 <link href="panel_assets/plugins/bxslider/css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
<!-- Custom Theme files -->
<link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />

<link href="assets/css/font-awesome.css" rel="stylesheet"> 
</head>

<body>
    
    <div class="container" id="" style="margin-top: 30px; margin-bottom: 30px;">
        <div><a href="home" class="btn btn-primary hidden-print">Home</a></div>
        <div class="row">
            <button onclick="window.print();" class="col-md-offset-4 col-md-4 btn btn-rounded btn-success hidden-print">Print This Invoice</button> 
        </div> 
   
        <hr>
       <?=$get_invoice?> 
        <hr>
   <div class="row">
            <button onclick="window.print();" class="col-md-offset-4 col-md-4 btn btn-rounded btn-success hidden-print">Print This Invoice</button> 
        </div> 
    </div> 
    
    <footer>
        <p align="center">Proudly Crafted By Craft-Igniter&reg;</p>
    </footer>
</body>
</html>