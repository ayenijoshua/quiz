	<?php $__env->startSection('title'); ?>
        Home
        <?php $__env->stopSection(); ?>
        
        <?php $__env->startSection('scripts'); ?>
       <script>
    $(document).ready(function() {


    });
   </script>
        <?php $__env->stopSection(); ?>
        
         <?php $__env->startSection('content'); ?>
           
	<!-- Block slideshow  -->
	<section class="so-slideshow ">
		<div class="container">
		<div class="row">
			<div id="so-slideshow">
				<div class="module slideshow--home8 no-margin">
					<?=$get_carousel?>
				</div>
				<div class="loadeding"></div>
			</div>
		</div>
		</div>		
	</section>
	<!-- //Block slideshow  -->
	
	<!-- Main Container  -->
	<div class="main-container ">
		<div class="container">
		<div class="row">
			<div id="content-top" class="clearfix" >
			
				<div class="container-full home8--banner1">
					<div class="container">
						<div class="row">
                                                    <?php foreach ($top_featured as $product){?>
							<div class="col-md-4 col-xs-12 banner-item">
								
								<div class="banners banner__img">
									<div>
										<a title="Static Image" href="#"><img src="products_img/<?=$product->product_fv_path?>" alt="Static Image"></a>
									</div>
								</div>
								<div class="banner__info">
									<h2><?=$controller->selectObject('category_name','categories','category_id',$product->category_id)?></h2>
									<p><?=$controller->selectObject('category_desc','categories','category_id',$product->category_id)?></p>
									<a title="Shop Now" href="products?cat=<?=$product->category_id?>">Shop Now &gt;&gt;</a>
								</div>
							</div>
                                                    <?php } ?>	
						</div>
					</div>
				</div>
			</div>
			
			
			<div id="content" class="clearfix">
				<div class="col-xs-12 clearfix">
					
					<div class="module so-extraslider--new titleLine">
						<h3 class="modtitle">New Arrivals</h3>
						<div id="so_extraslider1" >
							
							<!-- Begin extraslider-inner -->
							<div class="so-extraslider products-list grid"  data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="25" data-items_column0="5" data-items_column1="4" data-items_column2="3"  data-items_column3="2" data-items_column4="1" data-arrows="yes" data-pagination="no" data-lazyload="yes" data-loop="no" data-hoverpause="yes">
							
								<!--Begin Items-->
								<?=$new_arrivals?>
								<!--End Items-->
								
							</div>
							<!--End extraslider-inner -->
						</div>
					</div>
					
					<div class="module container-full home8--banner2">
						<div class="container"><a href="#" title="Static Image"><img src="assets/image/demo/cms/home8/image2-id12.png" alt="Static Image"></a></div>
					</div>
					
					<div class="module container-full home8--banner3">
						
							<div class="owl-banner__slider">
                                                            <?php foreach($middle_featured as $product) { ?>
								<div class="banner__item">
									<div class="banners banner__img">
                                                                            <div style="width:300px;">
                                                                                    <a title="Static Image" href="products?cat=<?=$product->category_id?>"><img height="200px" width="100px" src="products_img/<?=$product->product_fv_path?>" alt="Static Image"></a>
										</div>
									</div>
									<div class="banner__info">
                                                                        <p><?=$controller->selectObject('category_desc','categories','category_id',$product->category_id)?></p>
									<h2><?=$controller->selectObject('category_name','categories','category_id',$product->category_id)?></h2>
									<a title="Shop Now" href="products?cat=<?=$product->category_id?>">Shop Now &gt;&gt;</a>
								</div>
								</div>
                                                            <?php } ?>
								
							</div>
						
					</div>
					
					<div class="products-slider-bottom">
						<div class="row">

							<div class="module so-extraslider--new titleLine col-sm-6 col-xs-12">
								<h3 class="modtitle modtitle--small">Other Products</h3>
								<div id="so_extraslider1__home8">
									
									<!-- Begin extraslider-inner -->
									<div class="so-extraslider products-list grid product-style__8"  data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="3" data-items_column1="2" data-items_column2="1"  data-items_column3="1" data-items_column4="1" data-arrows="yes" data-pagination="no" data-lazyload="yes" data-loop="no" data-hoverpause="yes">
										<!--Begin Items-->
                                                                                <?php foreach ($other_product1 as $product) {  ?>
										<div class="ltabs-item product-layout">
                                                                                    
											<div class="product-item-container">
                                                                                            
												<div class="left-block">
													<div class="product-image-container second_img">
														<img src="products_img/<?=$product->product_fv_path?>"  alt="Apple Cinema 30&quot;" class="img-responsive" />
                                                                                                                <img src="products_img/<?=$product->product_bv_path?>"  alt="Apple Cinema 30&quot;" class="img-responsive img_0 img-responsive" />
													</div>
													<!--Sale Label-->
													<span class="label label-sale"><?=$product->product_condition?></span>
													
													<!--full quick view block-->
													<a class="quickview iframe-link visible-lg" data-fancybox-type="iframe"  href="quickview?id=<?=$product->product_id?>">  Quickview
                                                                                                          <div style="background-color:orange;"><?=$product_controller->getListOfObj($product->size_id)?></div>  
                                                                                                        </a>
													<!--end full quick view block-->
												</div>
                                                                                            
												<div class="right-block">
													<div class="caption">
														<h4><a href="product-details?id=<?=$product->product_id?>"><?=$product->product_name?></a></h4>		
														<div class="ratings">
															<div class="rating-box">
																<span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
																<span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
																<span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
																<span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
																<span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
															</div>
														</div>
																			
														<div class="price">
															<span class="price-new">₦<?=$product->product_price?></span> 
															<span class="price-old"><?=$product->product_discount?></span>	
														</div>
													</div>
													
                                <div class="button-group">
                        <form class="add-to-cart-form" style="display:inline" action="manage-cart" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="action" value="add" />
                        <input type="hidden" name="product_id" value="<?=$product->product_id?>" /> 
                        <input type="hidden" name="product_price" value="<?=$product->product_price?>" />
                        <input type="hidden" name="product_name" value="<?=$product->product_name?>" />
                        <input type="hidden" name="product_img" value="<?=$product->product_fv_path?>" />
                        <input type="hidden" name="product_qty" value="<?=$product->product_qty?>" />
                        <input type="hidden" name="product_size" value="<?=$product->size_id?>" />
                        <button class="addToCart add-to-cart-btn" type="submit" data-toggle="tooltip" title="Add to Cart" onclick=""><i class="fa fa-shopping-cart"></i> <span class="hidden-xs">Add to Cart</span></button>
                        </form>        
			<form class="add-to-whistlist-form" style="display:inline" action="manage-whishlist" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="action" value="add" />
                        <input type="hidden" name="product_id" value="<?=$product->product_id?>" /> 
                        <input type="hidden" name="product_price" value="<?=$product->product_price?>" />
                        <input type="hidden" name="product_name" value="<?=$product->product_name?>" />
                        <input type="hidden" name="product_img" value="<?=$product->product_fv_path?>" />
                        <input type="hidden" name="product_qty" value="<?=$product->product_qty?>" />
                        <input type="hidden" name="product_size" value="<?=$product->size_id?>" />
		        <button class="wishlist  add-to-whishlist-btn" style="" type="submit" data-toggle="tooltip" title="Add to Wish List" onclick=""><i class="fa fa-heart"></i></button>
                        </form>
		        </div>
												</div><!-- right block -->
											</div>
                                                                                   
										</div>
										 <?php } ?>
										
										<!--End Items-->
										
										
									</div>
									<!--End extraslider-inner -->
								</div>
							</div>
							<div class="module so-extraslider--new titleLine col-sm-6 col-xs-12">
								<h3 class="modtitle modtitle--small">Recommendation</h3>
								<div id="so_extraslider1__home8">
									
									<!-- Begin extraslider-inner -->
									<div class="so-extraslider products-list grid product-style__8"  data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="3" data-items_column1="2" data-items_column2="1"  data-items_column3="1" data-items_column4="1" data-arrows="yes" data-pagination="no" data-lazyload="yes" data-loop="no" data-hoverpause="yes">
										<!--Begin Items-->
                                                                                <?php foreach ($other_product2 as $product) {  ?>
										<div class="ltabs-item product-layout">
                                                                                    
											<div class="product-item-container">
                                                                                            
												<div class="left-block">
													<div class="product-image-container second_img">
														<img src="products_img/<?=$product->product_fv_path?>"  alt="Apple Cinema 30&quot;" class="img-responsive" />
                                                                                                                <img src="products_img/<?=$product->product_bv_path?>"  alt="Apple Cinema 30&quot;" class="img-responsive img_0 img-responsive" />
													</div>
													<!--Sale Label-->
													<span class="label label-sale"><?=$product->product_condition?></span>
													
													<!--full quick view block-->
													<a class="quickview iframe-link visible-lg" data-fancybox-type="iframe"  href="quickview?id=<?=$product->product_id?>">  Quickview
                                                                                                          <div style="background-color:orange;"><?=$product_controller->getListOfObj($product->size_id)?></div>  
                                                                                                        </a>
													<!--end full quick view block-->
												</div>
                                                                                            
												<div class="right-block">
													<div class="caption">
                                                                                                            <h4><a href="product-details?id=<?=$product->product_id?>"><?=$product->product_name?></a></h4>		
														<div class="ratings">
															<div class="rating-box">
																<span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
																<span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
																<span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
																<span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
																<span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
															</div>
														</div>
																			
														<div class="price">
															<span class="price-new">₦<?=$product->product_price?></span> 
															<span class="price-old">₦<?=$product->product_discount?></span>	
														</div>
													</div>
													
                          <div class="button-group">
                        <form class="add-to-cart-form" style="display:inline" action="manage-cart" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="action" value="add" />
                        <input type="hidden" name="product_id" value="<?=$product->product_id?>" /> 
                        <input type="hidden" name="product_price" value="<?=$product->product_price?>" />
                        <input type="hidden" name="product_name" value="<?=$product->product_name?>" />
                        <input type="hidden" name="product_img" value="<?=$product->product_fv_path?>" />
                        <input type="hidden" name="product_qty" value="<?=$product->product_qty?>" />
                        <input type="hidden" name="product_size" value="<?=$product->size_id?>" />
                        <button class="addToCart add-to-cart-btn" type="submit" data-toggle="tooltip" title="Add to Cart" onclick="">
                        <i class="fa fa-shopping-cart"></i> <span class="hidden-xs">Add to Cart</span></button>
                        </form>        
			<form class="add-to-whistlist-form" style="display:inline" action="manage-whishlist" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="action" value="add" />
                        <input type="hidden" name="product_id" value="<?=$product->product_id?>" /> 
                        <input type="hidden" name="product_price" value="<?=$product->product_price?>" />
                        <input type="hidden" name="product_name" value="<?=$product->product_name?>" />
                        <input type="hidden" name="product_img" value="<?=$product->product_fv_path?>" />
                        <input type="hidden" name="product_qty" value="<?=$product->product_qty?>" />
                        <input type="hidden" name="product_size" value="<?=$product->size_id?>" />
		        <button class="wishlist  add-to-whishlist-btn" style="" type="submit" data-toggle="tooltip" title="Add to Wish List" onclick="">
                            <i class="fa fa-heart"></i></button>
                        </form>
		        </div>
												</div><!-- right block -->
											</div>
                                                                                   
										</div>
										 <?php } ?>
										
									
										<!--End Items-->
										
										
									</div>
									<!--End extraslider-inner -->
								</div>
							</div>
								
						</div>
					</div>
					<div class="module titleLine">
						<h3 class="modtitle modtitle--small">Trending</h3>
						<div class="modcontent clearfix">
							<div class="yt-content-slider slider-blog-post"  data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="10" data-items_column0="4" data-items_column1="3" data-items_column2="2"  data-items_column3="1" data-items_column4="1" data-arrows="yes" data-pagination="no" data-lazyload="yes" data-loop="yes" data-hoverpause="yes">
                                                            <?php foreach ($trending as $trends) { ?>
								<div class="item-post">
									<div class="banners image-blog ">
										<div>
                                                                                    <a class="quickview iframe-link visible-lg" data-fancybox-type="iframe"  title="<?=$trends->product_name?>" href="quickview?id=<?=$trends->product_id?>">
											<img src="products_img/<?=$trends->product_fv_path?>" alt="Blog Image">
									            </a>
                                                                                    <a class=" visible-xs visible-sm visible-md"  title="<?=$trends->product_name?>" href="product-details?id=<?=$trends->product_id?>">
											<img src="products_img/<?=$trends->product_fv_path?>" alt="Blog Image">
									            </a>
										</div>
									</div>
									<div class="info-blog">
                                                                            <h2 class="postTitle"><a href="product-details?id=<?=$trends->product_id?>"><?=$trends->product_name?></a></h2>
										<div class="date-post-title">
											
                                                                            <div class="btn-group">
                                                                    <form class="add-to-cart-form" style="display:inline" action="manage-cart" method="post">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <input type="hidden" name="action" value="add" />
                                                                    <input type="hidden" name="product_id" value="<?=$product->product_id?>" /> 
                                                                    <input type="hidden" name="product_price" value="<?=$product->product_price?>" />
                                                                    <input type="hidden" name="product_name" value="<?=$product->product_name?>" />
                                                                    <input type="hidden" name="product_img" value="<?=$product->product_fv_path?>" />
                                                                    <input type="hidden" name="product_qty" value="<?=$product->product_qty?>" />
                                                                    <input type="hidden" name="product_size" value="<?=$product->size_id?>" />
                                                                    <button class="addToCart add-to-cart-btn btn btn-warning" type="submit" data-toggle="tooltip" title="Add to Cart" onclick="">
                                                                    <i class="fa fa-shopping-cart"></i><span class="hidden-xs">Add to Cart</span> </button>
                                                                    </form>  
                                                                                                
                                                                    <form class="add-to-whistlist-form" style="display:inline" action="manage-whishlist" method="post">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <input type="hidden" name="action" value="add" />
                                                                    <input type="hidden" name="product_id" value="<?=$product->product_id?>" /> 
                                                                    <input type="hidden" name="product_price" value="<?=$product->product_price?>" />
                                                                    <input type="hidden" name="product_name" value="<?=$product->product_name?>" />
                                                                    <input type="hidden" name="product_img" value="<?=$product->product_fv_path?>" />
                                                                    <input type="hidden" name="product_qty" value="<?=$product->product_qty?>" />
                                                                    <input type="hidden" name="product_size" value="<?=$product->size_id?>" />
                                                                    <button class="wishlist add-to-whishlist-btn btn btn-warning" style="" type="submit" data-toggle="tooltip" title="Add to Wish List" onclick="">
                                                                        <i class="fa fa-heart"></i></button>
                                                                    </form>
                                                                                            </div>
											
                                                                                    
										</div>
                                                                           
									</div>
								</div>
                                                            <?php } ?>	
							</div>
							
						</div>
					</div>	
					
					<div class="module">
						<div class="yt-content-slider yt-content-slider--arrow2"  data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="35" data-items_column0="5" data-items_column1="4" data-items_column2="3"  data-items_column3="2" data-items_column4="1" data-arrows="yes" data-pagination="no" data-lazyload="yes" data-loop="yes" data-hoverpause="yes">
							<div class="item">
								<a title="Brand" href="#"><img src="assets/image/demo/brand/home5/logo-1.png" alt="Brand">
								</a>
							</div>
							<div class="item">
								<a title="Brand" href="#"><img src="assets/image/demo/brand/home5/logo-2.png" alt="Brand">
								</a>
							</div>
							<div class="item">
								<a title="Brand" href="#"><img src="assets/image/demo/brand/home5/logo-3.png" alt="Brand">
								</a>
							</div>
							<div class="item">
								<a title="Brand" href="#"><img src="assets/image/demo/brand/home5/logo-1.png" alt="Brand">
								</a>
							</div>
							<div class="item">
								<a title="Brand" href="#"><img src="assets/image/demo/brand/home5/logo-2.png" alt="Brand">
								</a>
							</div>
							<div class="item">
								<a title="Brand" href="#"><img src="assets/image/demo/brand/home5/logo-3.png" alt="Brand">
								</a>
							</div>
						</div>
						
					</div>
					
				</div>
			</div>
		</div>
		</div>
	</div>
	<!-- //Main Container -->
	
<script type="text/javascript"><!--
	var $typeheader = 'header-home1';
	//-->
</script>

	<?php $__env->stopSection(); ?>
         
        
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>