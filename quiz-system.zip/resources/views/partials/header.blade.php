<!doctype html>
<html lang="en">
  
<!-- Mirrored from getbootstrap.com/docs/4.0/examples/album/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 30 Jan 2018 15:12:42 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="http://getbootstrap.com/favicon.ico">
     <link rel="icon" href="assets/font-awesome/css/font-awesome.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <title>Album example for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    
<link href="assets/select2/select2.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="album.css" rel="stylesheet">
    <script src="assets/dist/js/jquery-3.1.1.min.js"></script>
    <link rel="stylesheet" href="assets/dropify/dist/css/dropify.min.css">
     <script>
 
$(document).ready(function() { 
        loginProcessor('#login-form','.login_btn','.msg','manage-user');
        formProcessor('#signup-form','.signup_btn','.msg1','Sign Up','manage-user');
        formProcessorWithFileCallbacks('#upload','upload_btn','.msg2','upload','manage-user');
        
        
        
}); 

</script>
    
  </head>
  <body>
      
      