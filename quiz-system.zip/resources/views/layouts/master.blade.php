
@include('partials.header')


@yield('scripts')

@yield('content')

@include('partials.footer')